<?php
require_once __DIR__ . '/../models/Rol.php';

class RolController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Rol();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;

        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $roles = $this->modelo->findAllCustomPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/rol/listarrol.php';
    }

    public function registro()
    {
        require_once __DIR__ . '/../views/rol/registrarrol.php';
    }

    public function registrar()
    {
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;

        if ($this->modelo->verificarNombreExistente($nombre)) {
            echo "<script>alert('Error: El rol ya existe en la base de datos.'); window.history.back();</script>";
            exit;
        }

        $this->modelo->add($nombre, $estado);

        header('Location: /almaceneslibertad/public/?controller=rol&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        // Capturamos la página actual para pasarla a la vista
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id <= 0) {
            echo "ID de rol inválido.";
            return;
        }

        $resultado = $this->modelo->findById($id);

        if ($resultado && is_object($resultado) && $resultado->num_rows > 0) {
            $rol = $resultado->fetch_assoc();
            
            // Ruta corregida y verificada con el estándar de carpetas:
            require_once __DIR__ . '/../views/rol/actualizarrol.php';
        } else {
            echo "Rol no encontrado.";
        }
    }

    public function actualizar()
    {
        $id     = $_POST['txtCod'] ?? 0;
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;
        // Capturamos la página enviada desde el campo oculto
        $pagina = isset($_POST['page']) ? (int)$_POST['page'] : 1;

        if ($this->modelo->nombreYaExisteParaOtro($id, $nombre)) {
            echo "<script>alert('Error: Ya existe otro rol con ese nombre.'); window.history.back();</script>";
            exit;
        }

        if ($id > 0) {
            $this->modelo->update($id, $nombre, $estado);
        }

        header('Location: /almaceneslibertad/public/?controller=rol&action=listar&page=' . $pagina);
        exit;
    }

    public function eliminar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        
        if ($id > 0) {
            $this->modelo->delete($id);
        }
        header('Location: /almaceneslibertad/public/?controller=rol&action=listar&page=' . $pagina);
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;

        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $roles = $this->modelo->findAllPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/rol/habilitarrol.php';
    }

    public function habilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->enable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=rol&action=habilita&page=' . $pagina);
        exit;
    }

    public function deshabilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->disable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=rol&action=habilita&page=' . $pagina);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}