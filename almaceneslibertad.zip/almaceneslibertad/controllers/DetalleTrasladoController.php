<?php
require_once __DIR__ . '/../models/DetalleTraslado.php';
require_once __DIR__ . '/../models/InventarioAlmacen.php';
require_once __DIR__ . '/../models/Producto.php';

class DetalleTrasladoController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new DetalleTraslado();
    }

    /*
     * listar() — Responde peticiones AJAX del modal de detalle de traslado.
     * Devuelve JSON con las líneas del detalle para el codtra recibido por GET.
     */
    public function listar()
    {
        header('Content-Type: application/json');
        $codtra    = isset($_GET['codtra']) ? (int) $_GET['codtra'] : 0;
        $resultado = $this->modelo->findByTraslado($codtra);
        $filas     = [];

        if ($resultado && $resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $filas[] = [
                    'coddettra' => $fila['coddettra'],
                    'codpro'    => $fila['codpro'],
                    'nompro'    => $fila['nompro'],
                    'cantra'    => $fila['cantra'],
                ];
            }
        }

        echo json_encode([
            'success' => true,
            'codtra'  => $codtra,
            'items'   => $filas,
        ]);
        exit;
    }

    /*
     * registrar() — Añade una línea al detalle y mueve stock entre almacenes.
     * Recibe por POST: codtra, codpro, cantra, codalmorigen, codalmdestino.
     *
     * Lógica de stock:
     *   - Almacén ORIGEN  → stockactual -= cantra  (validando que haya suficiente)
     *   - Almacén DESTINO → stockactual += cantra  (crea registro si no existe)
     */
    public function registrar()
    {
        header('Content-Type: application/json');

        $codtra         = (int) ($_POST['codtra']         ?? 0);
        $codpro         = (int) ($_POST['codpro']         ?? 0);
        $cantra         = (int) ($_POST['cantra']         ?? 0);
        $codalmorigen   = (int) ($_POST['codalmorigen']   ?? 0);
        $codalmdestino  = (int) ($_POST['codalmdestino']  ?? 0);

        if ($codtra <= 0 || $codpro <= 0 || $cantra <= 0) {
            echo json_encode(['success' => false, 'mensaje' => 'Datos inválidos.']);
            exit;
        }

        if ($codalmorigen === $codalmdestino) {
            echo json_encode(['success' => false, 'mensaje' => 'El almacén origen y destino no pueden ser el mismo.']);
            exit;
        }

        $inv = new InventarioAlmacen();

        // ── Verificar stock en el almacén ORIGEN ─────────────────────────
        $resOrigen = $inv->findByAlmacenProducto($codalmorigen, $codpro);

        if (!$resOrigen || $resOrigen->num_rows === 0) {
            echo json_encode(['success' => false, 'mensaje' => 'El almacén origen no tiene este producto en inventario.']);
            exit;
        }

        $filaOrigen = $resOrigen->fetch_assoc();
        if ((int) $filaOrigen['stockactual'] < $cantra) {
            echo json_encode([
                'success' => false,
                'mensaje' => 'Stock insuficiente en origen. Disponible: ' . $filaOrigen['stockactual'],
            ]);
            exit;
        }

        // ── Insertar línea de detalle ─────────────────────────────────────
        $ok = $this->modelo->add($codtra, $codpro, $cantra);

        if ($ok) {
            // Descontar del ORIGEN
            $stockOrigen = (int) $filaOrigen['stockactual'] - $cantra;
            $inv->updateStockByAlmacenProducto($codalmorigen, $codpro, $stockOrigen);

            // Agregar al DESTINO
            $resDestino = $inv->findByAlmacenProducto($codalmdestino, $codpro);
            if ($resDestino && $resDestino->num_rows > 0) {
                $filaDestino   = $resDestino->fetch_assoc();
                $stockDestino  = (int) $filaDestino['stockactual'] + $cantra;
                $inv->updateStockByAlmacenProducto($codalmdestino, $codpro, $stockDestino);
            } else {
                $inv->add($codalmdestino, $codpro, $cantra);
            }
        }

        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Traslado registrado y stock actualizado en ambos almacenes.' : 'Error al registrar el detalle.',
        ]);
        exit;
    }

    /*
     * eliminar() — Elimina una línea de detalle por su PK (coddettra).
     * No revierte el stock automáticamente (la anulación se gestiona desde TrasladoController).
     */
    public function eliminar()
    {
        header('Content-Type: application/json');
        $coddettra = (int) ($_GET['id'] ?? 0);
        $ok        = $this->modelo->deleteLinea($coddettra);
        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Línea eliminada.' : 'Error al eliminar la línea.',
        ]);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>
