<?php
require_once __DIR__ . '/../models/Marca.php';

class MarcaController
{

    private $modelo;

    public function __construct()
    {
        $this->modelo = new Marca();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $marcas = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/marca/listarmarca.php';
    }

    public function registro()
    {
        require_once __DIR__ . '/../views/marca/registrarmarca.php';
    }

    public function registrar()
    {
        $nombre = $_POST['txtNom'] ?? "";
        $estado = isset($_POST['chkEst']) ? 1 : 0;

        if ($this->modelo->verificarNombreExistente($nombre)) {
            echo "<script>alert('Error: La marca ya existe en la base de datos.'); window.history.back();</script>";
            exit;
        }

        $this->modelo->add($nombre, $estado);
        header('Location: /almaceneslibertad/public/?controller=marca&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id <= 0) {
            echo "ID de marca inválido.";
            return;
        }

        $resultado = $this->modelo->findById($id);

        if ($resultado && is_object($resultado) && $resultado->num_rows > 0) {
            $marca = $resultado->fetch_assoc();
            require_once __DIR__ . '/../views/marca/actualizarmarca.php';
        } else {
            echo "Marca no encontrada.";
        }
    }

    public function actualizar()
    {
        $id = $_POST['txtCod'] ?? 0;
        $nombre = $_POST['txtNom'] ?? "";
        $estado = isset($_POST['chkEst']) ? 1 : 0;
        $pagina = isset($_POST['page']) ? (int)$_POST['page'] : 1;

        if ($this->modelo->nombreYaExisteParaOtro($id, $nombre)) {
            echo "<script>alert('Error: Ya existe otra marca con ese nombre.'); window.history.back();</script>";
            exit;
        }

        if ($id > 0) {
            $this->modelo->update($id, $nombre, $estado);
        }

        header('Location: /almaceneslibertad/public/?controller=marca&action=listar&page=' . $pagina);
        exit;
    }

    public function eliminar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->delete($id);
        }

        header('Location: /almaceneslibertad/public/?controller=marca&action=listar&page=' . $pagina);
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $marcas = $this->modelo->findAllPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/marca/habilitarmarca.php';
    }

    public function habilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->enable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=marca&action=habilita&page=' . $pagina);
        exit;
    }

    public function deshabilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->disable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=marca&action=habilita&page=' . $pagina);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
