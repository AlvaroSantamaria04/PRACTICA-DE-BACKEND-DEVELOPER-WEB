<?php
require_once __DIR__ . '/../models/InventarioAlmacen.php';
require_once __DIR__ . '/../models/Almacen.php';
require_once __DIR__ . '/../models/Producto.php';

class InventarioAlmacenController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new InventarioAlmacen();
    }

    // NOTA: InventarioAlmacen NO tiene campo estado; no existen métodos habilita/deshabilitar.
    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $inventarios = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/inventarioalmacen/listarinventarioalmacen.php';
    }

    public function registro()
    {
        $almacenes = (new Almacen())->findAllCustom();
        $productos = (new Producto())->findAllCustom();
        require_once __DIR__ . '/../views/inventarioalmacen/registrarinventarioalmacen.php';
    }

    public function registrar()
    {
        $almacen  = $_POST['selAlm'] ?? 0;
        $producto = $_POST['selPro'] ?? 0;
        $stock    = $_POST['txtSto'] ?? 0;
        $this->modelo->add($almacen, $producto, $stock);
        header('Location: /almaceneslibertad/public/?controller=inventarioalmacen&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $inventario = $resultado->fetch_assoc();
            $almacenes  = (new Almacen())->findAllCustom();
            $productos  = (new Producto())->findAllCustom();
            require_once __DIR__ . '/../views/inventarioalmacen/actualizarinventarioalmacen.php';
        } else {
            echo "Registro de inventario no encontrado";
        }
    }

    public function actualizar()
    {
        $id    = $_POST['txtCod'] ?? 0;
        $stock = $_POST['txtSto'] ?? 0;
        $this->modelo->update($id, $stock);
        header('Location: /almaceneslibertad/public/?controller=inventarioalmacen&action=listar');
        exit;
    }

    // Eliminación física (la tabla no tiene campo estado)
    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=inventarioalmacen&action=listar');
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>