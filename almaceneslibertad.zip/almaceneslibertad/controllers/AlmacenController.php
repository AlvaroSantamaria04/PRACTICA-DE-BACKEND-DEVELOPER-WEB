<?php
require_once __DIR__ . '/../models/Almacen.php';
require_once __DIR__ . '/../models/Sucursal.php';

class AlmacenController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Almacen();
    }

    // ── LISTAR (habilitados con paginación) ──────────────────
    public function listar()
    {
        $limite  = 10;
        $pagina  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio  = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas   = ceil($totalRegistros / $limite);
        $almacenes      = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/almacen/listaralmacen.php';
    }

    // ── FORMULARIO REGISTRO ──────────────────────────────────
    public function registro()
    {
        $sucursales = (new Sucursal())->findAllCustom();
        require_once __DIR__ . '/../views/almacen/registraralmacen.php';
    }

    // ── GUARDAR NUEVO ────────────────────────────────────────
    public function registrar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre    = isset($_POST['txtNom'])  ? trim($_POST['txtNom'])  : '';
            $tipo      = isset($_POST['cboTipo']) ? $_POST['cboTipo']      : 'Sucursal';
            $direccion = isset($_POST['txtDir'])  ? trim($_POST['txtDir'])  : '';
            $estado    = isset($_POST['chkEst'])  ? 1 : 0;

            // Central → codsuc = NULL; Sucursal vacía → NULL
            if ($tipo === 'Central' || empty($_POST['cboSucursal'])) {
                $codsuc = null;
            } else {
                $codsuc = (int) $_POST['cboSucursal'];
            }

            $guardado = $this->modelo->add($nombre, $tipo, $direccion, $estado, $codsuc);

            if ($guardado) {
                header('Location: /almaceneslibertad/public/?controller=almacen&action=listar');
                exit;
            } else {
                echo "Error al registrar el almacén.";
            }
        }
    }

    // ── FORMULARIO EDICIÓN ───────────────────────────────────
    public function actualiza()
    {
        $id        = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $almacen    = $resultado->fetch_assoc();
            $sucursales = (new Sucursal())->findAllCustom();
            require_once __DIR__ . '/../views/almacen/actualizaralmacen.php';
        } else {
            echo "Almacén no encontrado.";
        }
    }

    // ── GUARDAR EDICIÓN ──────────────────────────────────────
    public function actualizar()
    {
        $id        = $_POST['txtCod'] ?? 0;
        $nombre    = $_POST['txtNom'] ?? '';
        $tipo      = $_POST['selTip'] ?? '';
        $direccion = $_POST['txtDir'] ?? '';
        $estado    = isset($_POST['chkEst']) ? 1 : 0;
        $codsuc    = $_POST['selSuc'] ?? null;
        $codsuc    = ($codsuc === '' || $codsuc == 0 || $tipo === 'Central') ? null : (int) $codsuc;

        $this->modelo->update($id, $nombre, $tipo, $direccion, $estado, $codsuc);
        header('Location: /almaceneslibertad/public/?controller=almacen&action=listar');
        exit;
    }

    // ── ELIMINAR (lógico) ────────────────────────────────────
    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=almacen&action=listar');
        exit;
    }

    // ── HABILITA (panel habilitar/deshabilitar) ──────────────
    public function habilita()
    {
        $limite  = 10;
        $pagina  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio  = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas   = ceil($totalRegistros / $limite);
        $almacenes      = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/almacen/habilitaralmacen.php';
    }

    // ── HABILITAR ────────────────────────────────────────────
    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=almacen&action=habilita');
        exit;
    }

    // ── DESHABILITAR ─────────────────────────────────────────
    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=almacen&action=habilita');
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>
