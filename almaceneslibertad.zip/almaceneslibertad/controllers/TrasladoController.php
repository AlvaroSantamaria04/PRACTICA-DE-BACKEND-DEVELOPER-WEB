<?php
require_once __DIR__ . '/../models/Traslado.php';
require_once __DIR__ . '/../models/Almacen.php';
require_once __DIR__ . '/../models/Empleado.php';

class TrasladoController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Traslado();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $traslados = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/traslado/listartraslado.php';
    }

    public function registro()
    {
        $almacenes = (new Almacen())->findAllCustom();
        $empleados = (new Empleado())->findAllCustom();
        require_once __DIR__ . '/../views/traslado/registrartraslado.php';
    }

    public function registrar()
    {
        $fecha          = $_POST['txtFec']   ?? date('Y-m-d');
        $almacenOrigen  = $_POST['selAlmOri'] ?? 0;
        $almacenDestino = $_POST['selAlmDes'] ?? 0;
        $empleado       = $_POST['selEmp']   ?? 0;
        $estado         = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->add($fecha, $almacenOrigen, $almacenDestino, $empleado, $estado);
        header('Location: /almaceneslibertad/public/?controller=traslado&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $traslado  = $resultado->fetch_assoc();
            $almacenes = (new Almacen())->findAllCustom();
            $empleados = (new Empleado())->findAllCustom();
            require_once __DIR__ . '/../views/traslado/actualizartraslado.php';
        } else {
            echo "Traslado no encontrado";
        }
    }

    public function actualizar()
    {
        $id             = $_POST['txtCod']    ?? 0;
        $fecha          = $_POST['txtFec']    ?? date('Y-m-d');
        $almacenOrigen  = $_POST['selAlmOri'] ?? 0;
        $almacenDestino = $_POST['selAlmDes'] ?? 0;
        $empleado       = $_POST['selEmp']    ?? 0;
        $estado         = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->update($id, $fecha, $almacenOrigen, $almacenDestino, $empleado, $estado);
        header('Location: /almaceneslibertad/public/?controller=traslado&action=listar');
        exit;
    }

    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=traslado&action=listar');
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $traslados = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/traslado/habilitartraslado.php';
    }

    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=traslado&action=habilita');
        exit;
    }

    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=traslado&action=habilita');
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>