<?php
require_once __DIR__ . '/../models/Categoria.php';

class CategoriaController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Categoria();
    }

    // Mostrar listado de categorías EN ORDEN NUMÉRICO CORRECTO
    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        
        $inicio = ($pagina - 1) * $limite;
        
        // Cambiamos a countAll y findAllPaginated para respetar el orden ID 1, 2, 3...
        // y reflejar con total precisión el estado real (0 o 1) de la BD.
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $categorias = $this->modelo->findAllPaginated($inicio, $limite);
        
        // Exponer variables limpias a la vista
        unset($inicio, $limite); 

        require_once __DIR__ . '/../views/categoria/listarcategoria.php';
    }

    // Mostrar formulario de registro
    public function registro()
    {
        require_once __DIR__ . '/../views/categoria/registrarcategoria.php';
    }

    // Guardar nueva categoría
    public function registrar()
    {
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->add($nombre, $estado);
        header('Location: /almaceneslibertad/public/?controller=categoria&action=listar');
        exit;
    }

    // Mostrar formulario de edición
    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $categoria = $resultado->fetch_assoc();
            require_once __DIR__ . '/../views/categoria/actualizarcategoria.php';
        } else {
            echo "Categoría no encontrada";
        }
    }

    // Actualizar categoría
    public function actualizar()
    {
        $id     = $_POST['txtCod'] ?? 0;
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->update($id, $nombre, $estado);
        header('Location: /almaceneslibertad/public/?controller=categoria&action=listar');
        exit;
    }

    // Eliminación lógica
    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=categoria&action=listar');
        exit;
    }

    // Mostrar listado para habilitación/deshabilitación
    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $categorias = $this->modelo->findAllPaginated($inicio, $limite);
        
        require_once __DIR__ . '/../views/categoria/habilitarcategoria.php';
    }

    // Habilitar categoría
    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=categoria&action=habilita');
        exit;
    }

    // Deshabilitar categoría
    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=categoria&action=habilita');
        exit;
    }

    // Mostrar menú principal
    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>