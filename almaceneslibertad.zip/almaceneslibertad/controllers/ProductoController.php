<?php
require_once __DIR__ . '/../models/Producto.php';
require_once __DIR__ . '/../models/Categoria.php';
require_once __DIR__ . '/../models/Marca.php';

class ProductoController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Producto();
    }

    // ── LISTAR (todos: activos + inactivos, gestión unificada) ──
    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;

        $totalRegistros = $this->modelo->countAll();
        $totalPaginas   = ceil($totalRegistros / $limite);
        $productos      = $this->modelo->findAllPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/producto/listarproducto.php';
    }

    // ── FORMULARIO REGISTRO ──
    public function registro()
    {
        $categorias = (new Categoria())->findAllCustom();
        $marcas     = (new Marca())->findAllCustom();
        require_once __DIR__ . '/../views/producto/registrarproducto.php';
    }

    // ── GUARDAR NUEVO ──
    public function registrar()
    {
        $nombre      = trim($_POST['txtNom'] ?? '');
        $descripcion = trim($_POST['txtDes'] ?? '');
        $precio      = $_POST['txtPre'] ?? 0;
        $cantidad    = $_POST['txtCan'] ?? 0;
        $estado      = isset($_POST['chkEst']) ? 1 : 0;
        $categoria   = $_POST['selCat'] ?? 0;
        $marca       = $_POST['selMar'] ?? 0;
        $this->modelo->add($nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca);
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar');
        exit;
    }

    // ── FORMULARIO EDICIÓN ──
    public function actualiza()
    {
        $id        = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $producto   = $resultado->fetch_assoc();
            $categorias = (new Categoria())->findAll();
            $marcas     = (new Marca())->findAll();
            require_once __DIR__ . '/../views/producto/actualizarproducto.php';
        } else {
            echo 'Producto no encontrado';
        }
    }

    // ── GUARDAR EDICIÓN ──
    public function actualizar()
    {
        $id          = isset($_POST['txtCod']) ? (int) $_POST['txtCod'] : 0;
        $nombre      = trim($_POST['txtNom'] ?? '');
        $descripcion = trim($_POST['txtDes'] ?? '');
        $precio      = isset($_POST['txtPre']) ? floatval(str_replace(',', '.', $_POST['txtPre'])) : 0;
        $cantidad    = isset($_POST['txtCan']) ? (int) $_POST['txtCan'] : 0;
        $estado      = isset($_POST['chkEst']) ? 1 : 0;
        $categoria   = isset($_POST['selCat']) ? (int) $_POST['selCat'] : 0;
        $marca       = isset($_POST['selMar']) ? (int) $_POST['selMar'] : 0;
        $success = $this->modelo->update($id, $nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca);
        if (!$success) {
            echo 'Error al actualizar el producto';
            exit;
        }
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar');
        exit;
    }

    // ── ELIMINAR (lógico → deshabilita) ──
    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar');
        exit;
    }

    // ── HABILITAR (redirige a listar, gestión unificada) ──
    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar&page=' . ($_GET['page'] ?? 1));
        exit;
    }

    // ── DESHABILITAR (redirige a listar, gestión unificada) ──
    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar&page=' . ($_GET['page'] ?? 1));
        exit;
    }

    // ── HABILITA (obsoleto — redirige a listar) ──
    public function habilita()
    {
        header('Location: /almaceneslibertad/public/?controller=producto&action=listar');
        exit;
    }

    // ── MENÚ ──
    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>