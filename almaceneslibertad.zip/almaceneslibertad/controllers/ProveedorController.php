<?php
require_once __DIR__ . '/../models/Proveedor.php';
require_once __DIR__ . '/../models/Distrito.php';

class ProveedorController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Proveedor();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $proveedores = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/proveedor/listarproveedor.php';
    }

    public function registro()
    {
        $distritos = (new Distrito())->findAllCustom();
        require_once __DIR__ . '/../views/proveedor/registrarproveedor.php';
    }

    public function registrar()
    {
        $nombre         = $_POST['txtNom'] ?? '';
        $representante  = $_POST['txtRep'] ?? '';
        $direccion      = $_POST['txtDir'] ?? '';
        $telefono       = $_POST['txtTel'] ?? '';
        $celular        = $_POST['txtCel'] ?? '';
        $correo         = $_POST['txtCor'] ?? '';
        $estado         = isset($_POST['chkEst']) ? 1 : 0;
        $distrito       = $_POST['selDis'] ?? 0;
        $this->modelo->add($nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito);
        header('Location: /almaceneslibertad/public/?controller=proveedor&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $proveedor = $resultado->fetch_assoc();
            $distritos = (new Distrito())->findAllCustom();
            require_once __DIR__ . '/../views/proveedor/actualizarproveedor.php';
        } else {
            echo "Proveedor no encontrado";
        }
    }

    public function actualizar()
    {
        $id             = $_POST['txtCod'] ?? 0;
        $nombre         = $_POST['txtNom'] ?? '';
        $representante  = $_POST['txtRep'] ?? '';
        $direccion      = $_POST['txtDir'] ?? '';
        $telefono       = $_POST['txtTel'] ?? '';
        $celular        = $_POST['txtCel'] ?? '';
        $correo         = $_POST['txtCor'] ?? '';
        $estado         = isset($_POST['chkEst']) ? 1 : 0;
        $distrito       = $_POST['selDis'] ?? 0;
        $this->modelo->update($id, $nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito);
        header('Location: /almaceneslibertad/public/?controller=proveedor&action=listar');
        exit;
    }

    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=proveedor&action=listar');
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $proveedores = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/proveedor/habilitarproveedor.php';
    }

    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=proveedor&action=habilita');
        exit;
    }

    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=proveedor&action=habilita');
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>