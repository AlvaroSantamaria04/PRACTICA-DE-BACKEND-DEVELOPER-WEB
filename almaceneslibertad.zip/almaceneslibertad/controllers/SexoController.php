<?php
require_once __DIR__ . '/../models/Sexo.php';

class SexoController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Sexo();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;

        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $sexos = $this->modelo->findAllCustomPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/sexo/listarsexo.php';
    }

    public function registro()
    {
        require_once __DIR__ . '/../views/sexo/registrarsexo.php';
    }

    public function registrar()
    {
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;

        if ($this->modelo->verificarNombreExistente($nombre)) {
            echo "<script>alert('Error: El registro de sexo ya existe en la base de datos.'); window.history.back();</script>";
            exit;
        }

        $this->modelo->add($nombre, $estado);

        header('Location: /almaceneslibertad/public/?controller=sexo&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        // Capturamos la página actual para pasarla a la vista
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id <= 0) {
            echo "ID de sexo inválido.";
            return;
        }

        $resultado = $this->modelo->findById($id);

        if ($resultado && is_object($resultado) && $resultado->num_rows > 0) {
            $sexo = $resultado->fetch_assoc();
            require_once __DIR__ . '/../views/sexo/actualizarsexo.php';
        } else {
            echo "Sexo no encontrado.";
        }
    }

    public function actualizar()
    {
        $id     = $_POST['txtCod'] ?? 0;
        $nombre = $_POST['txtNom'] ?? '';
        $estado = isset($_POST['chkEst']) ? 1 : 0;
        // Capturamos la página enviada desde el campo oculto
        $pagina = isset($_POST['page']) ? (int)$_POST['page'] : 1;

        if ($this->modelo->nombreYaExisteParaOtro($id, $nombre)) {
            echo "<script>alert('Error: Ya existe otro registro de sexo con ese nombre.'); window.history.back();</script>";
            exit;
        }

        if ($id > 0) {
            $this->modelo->update($id, $nombre, $estado);
        }

        header('Location: /almaceneslibertad/public/?controller=sexo&action=listar&page=' . $pagina);
        exit;
    }

    public function eliminar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        
        if ($id > 0) {
            $this->modelo->delete($id);
        }
        header('Location: /almaceneslibertad/public/?controller=sexo&action=listar&page=' . $pagina);
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;

        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $sexos = $this->modelo->findAllPaginated($inicio, $limite);

        require_once __DIR__ . '/../views/sexo/habilitarsexo.php';
    }

    public function habilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->enable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=sexo&action=habilita&page=' . $pagina);
        exit;
    }

    public function deshabilitar()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($id > 0) {
            $this->modelo->disable($id);
        }

        header('Location: /almaceneslibertad/public/?controller=sexo&action=habilita&page=' . $pagina);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}