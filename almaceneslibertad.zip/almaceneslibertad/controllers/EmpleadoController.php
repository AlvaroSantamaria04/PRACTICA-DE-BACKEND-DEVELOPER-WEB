<?php
require_once __DIR__ . '/../models/Empleado.php';
require_once __DIR__ . '/../models/Distrito.php';
require_once __DIR__ . '/../models/Rol.php';
require_once __DIR__ . '/../models/TipoDocumento.php';
require_once __DIR__ . '/../models/Sucursal.php';
require_once __DIR__ . '/../models/Sexo.php';

class EmpleadoController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Empleado();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $empleados = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/empleado/listarempleado.php';
    }

    public function registro()
    {
        $distritos      = (new Distrito())->findAllCustom();
        $roles          = (new Rol())->findAllCustom();
        $tiposdocumento = (new TipoDocumento())->findAllCustom();
        $sucursales     = (new Sucursal())->findAllCustom();
        $sexos          = (new Sexo())->findAllCustom();
        require_once __DIR__ . '/../views/empleado/registrarempleado.php';
    }

    public function registrar()
    {
        $nombre    = $_POST['txtNom']  ?? '';
        $apePat    = $_POST['txtApep'] ?? '';
        $apeMat    = $_POST['txtApem'] ?? '';
        $documento = $_POST['txtDoc']  ?? '';
        $direccion = $_POST['txtDir']  ?? '';
        $telefono  = $_POST['txtTel']  ?? '';
        $celular   = $_POST['txtCel']  ?? '';
        $correo    = $_POST['txtCor']  ?? '';
        $estado    = isset($_POST['chkEst']) ? 1 : 0;
        $distrito  = $_POST['selDis']  ?? 0;
        $rol       = $_POST['selRol']  ?? 0;
        $tipoDoc   = $_POST['selTip']  ?? 0;
        $sucursal  = $_POST['selSuc']  ?? 0;
        $sexo      = $_POST['selSex']  ?? 0;

        $this->modelo->add(
            $nombre, $apePat, $apeMat, $documento, $direccion,
            $telefono, $celular, $correo, $estado,
            $distrito, $rol, $tipoDoc, $sucursal, $sexo
        );
        header('Location: /almaceneslibertad/public/?controller=empleado&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $empleado       = $resultado->fetch_assoc();
            $distritos      = (new Distrito())->findAllCustom();
            $roles          = (new Rol())->findAllCustom();
            $tiposdocumento = (new TipoDocumento())->findAllCustom();
            $sucursales     = (new Sucursal())->findAllCustom();
            $sexos          = (new Sexo())->findAllCustom();
            require_once __DIR__ . '/../views/empleado/actualizarempleado.php';
        } else {
            echo "Empleado no encontrado";
        }
    }

    public function actualizar()
    {
        $id        = $_POST['txtCod']  ?? 0;
        $nombre    = $_POST['txtNom']  ?? '';
        $apePat    = $_POST['txtApep'] ?? '';
        $apeMat    = $_POST['txtApem'] ?? '';
        $documento = $_POST['txtDoc']  ?? '';
        $direccion = $_POST['txtDir']  ?? '';
        $telefono  = $_POST['txtTel']  ?? '';
        $celular   = $_POST['txtCel']  ?? '';
        $correo    = $_POST['txtCor']  ?? '';
        $estado    = isset($_POST['chkEst']) ? 1 : 0;
        $distrito  = $_POST['selDis']  ?? 0;
        $rol       = $_POST['selRol']  ?? 0;
        $tipoDoc   = $_POST['selTip']  ?? 0;
        $sucursal  = $_POST['selSuc']  ?? 0;
        $sexo      = $_POST['selSex']  ?? 0;

        $this->modelo->update(
            $id, $nombre, $apePat, $apeMat, $documento, $direccion,
            $telefono, $celular, $correo, $estado,
            $distrito, $rol, $tipoDoc, $sucursal, $sexo
        );
        header('Location: /almaceneslibertad/public/?controller=empleado&action=listar');
        exit;
    }

    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=empleado&action=listar');
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $empleados = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/empleado/habilitarempleado.php';
    }

    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=empleado&action=habilita');
        exit;
    }

    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=empleado&action=habilita');
        exit;
    }

    public function login()
    {
        $usuario = $_POST['txtUsu'] ?? '';
        $clave   = $_POST['txtCla'] ?? '';
        $empleado = $this->modelo->login($usuario, $clave);
        if ($empleado) {
            session_start();
            $_SESSION['empleado'] = $empleado;
            header('Location: /almaceneslibertad/public/?controller=empleado&action=menu');
            exit;
        } else {
            $mensaje = "Usuario o clave incorrecta";
            require_once __DIR__ . '/../views/ingreso.php';
        }
    }

    public function logout()
    {
        session_start();
        session_unset();
        session_destroy();
        $mensaje = null;
        require_once __DIR__ . '/../views/ingreso.php';
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>