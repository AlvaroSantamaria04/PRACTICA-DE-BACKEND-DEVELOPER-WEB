<?php
require_once __DIR__ . '/../models/DetalleEntrada.php';
require_once __DIR__ . '/../models/InventarioAlmacen.php';
require_once __DIR__ . '/../models/Producto.php';

class DetalleEntradaController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new DetalleEntrada();
    }

    /*
     * listar() — Responde peticiones AJAX del modal de detalle de entrada.
     * Devuelve JSON con las líneas del detalle para el nroent recibido por GET.
     */
    public function listar()
    {
        header('Content-Type: application/json');
        $nroent    = isset($_GET['nroent']) ? (int) $_GET['nroent'] : 0;
        $resultado = $this->modelo->findByEntrada($nroent);
        $filas     = [];
        $total     = 0;

        if ($resultado && $resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $filas[] = [
                    'nrodetent' => $fila['nrodetent'],
                    'codpro'    => $fila['codpro'],
                    'nompro'    => $fila['nompro'],
                    'canent'    => $fila['canent'],
                    'preent'    => number_format((float) $fila['preent'], 2),
                    'subtotal'  => number_format((float) $fila['subtotal'], 2),
                ];
                $total += (float) $fila['subtotal'];
            }
        }

        echo json_encode([
            'success' => true,
            'nroent'  => $nroent,
            'total'   => number_format($total, 2),
            'items'   => $filas,
        ]);
        exit;
    }

    /*
     * registrar() — Añade una línea al detalle y actualiza el inventario del almacén.
     * Recibe por POST: nroent, codpro, canent, preent.
     * Requiere también codalm (almacén destino) para actualizar inventarioalmacen.
     */
    public function registrar()
    {
        header('Content-Type: application/json');

        $nroent  = (int)   ($_POST['nroent']  ?? 0);
        $codpro  = (int)   ($_POST['codpro']  ?? 0);
        $canent  = (int)   ($_POST['canent']  ?? 0);
        $preent  = (float) ($_POST['preent']  ?? 0);
        $codalm  = (int)   ($_POST['codalm']  ?? 0);

        if ($nroent <= 0 || $codpro <= 0 || $canent <= 0 || $preent <= 0) {
            echo json_encode(['success' => false, 'mensaje' => 'Datos inválidos.']);
            exit;
        }

        // Insertar línea de detalle
        $ok = $this->modelo->add($canent, $preent, $nroent, $codpro);

        if ($ok && $codalm > 0) {
            // Actualizar inventario: buscar stock actual y sumar
            $inv    = new InventarioAlmacen();
            $resInv = $inv->findByAlmacenProducto($codalm, $codpro);

            if ($resInv && $resInv->num_rows > 0) {
                $filaInv    = $resInv->fetch_assoc();
                $nuevoStock = (int) $filaInv['stockactual'] + $canent;
                $inv->updateStockByAlmacenProducto($codalm, $codpro, $nuevoStock);
            } else {
                // Primera vez que entra este producto a este almacén
                $inv->add($codalm, $codpro, $canent);
            }
        }

        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Detalle registrado y stock actualizado.' : 'Error al registrar el detalle.',
        ]);
        exit;
    }

    /*
     * eliminar() — Elimina una línea de detalle por su PK (nrodetent).
     * No revierte el stock (anulación se gestiona desde RegistroEntrada).
     */
    public function eliminar()
    {
        header('Content-Type: application/json');
        $nrodetent = (int) ($_GET['id'] ?? 0);
        $ok        = $this->modelo->deleteLinea($nrodetent);
        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Línea eliminada.' : 'Error al eliminar la línea.',
        ]);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>
