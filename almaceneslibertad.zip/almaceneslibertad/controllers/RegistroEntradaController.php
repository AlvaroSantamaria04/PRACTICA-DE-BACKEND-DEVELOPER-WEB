<?php
require_once __DIR__ . '/../models/RegistroEntrada.php';
require_once __DIR__ . '/../models/Empleado.php';
require_once __DIR__ . '/../models/Proveedor.php';
require_once __DIR__ . '/../models/Almacen.php';

class RegistroEntradaController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new RegistroEntrada();
    }

    public function listar()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAllCustom();
        $totalPaginas = ceil($totalRegistros / $limite);
        $entradas = $this->modelo->findAllCustomPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/registroentrada/listarregistroentrada.php';
    }

    public function registro()
    {
        $empleados   = (new Empleado())->findAllCustom();
        $proveedores = (new Proveedor())->findAllCustom();
        $almacenes   = (new Almacen())->findAllCustom();
        require_once __DIR__ . '/../views/registroentrada/registrarregistroentrada.php';
    }

    public function registrar()
    {
        $fecha     = $_POST['txtFec']  ?? date('Y-m-d');
        $empleado  = $_POST['selEmp']  ?? 0;
        $proveedor = $_POST['selProv'] ?? 0;
        $almacen   = $_POST['selAlm']  ?? 0;
        $estado    = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->add($fecha, $empleado, $proveedor, $almacen, $estado);
        header('Location: /almaceneslibertad/public/?controller=registroentrada&action=listar');
        exit;
    }

    public function actualiza()
    {
        $id = $_GET['id'] ?? 0;
        $resultado = $this->modelo->findById($id);
        if ($resultado && $resultado->num_rows > 0) {
            $entrada     = $resultado->fetch_assoc();
            $empleados   = (new Empleado())->findAllCustom();
            $proveedores = (new Proveedor())->findAllCustom();
            $almacenes   = (new Almacen())->findAllCustom();
            require_once __DIR__ . '/../views/registroentrada/actualizarregistroentrada.php';
        } else {
            echo "Registro de entrada no encontrado";
        }
    }

    public function actualizar()
    {
        $id        = $_POST['txtCod']  ?? 0;
        $fecha     = $_POST['txtFec']  ?? date('Y-m-d');
        $empleado  = $_POST['selEmp']  ?? 0;
        $proveedor = $_POST['selProv'] ?? 0;
        $almacen   = $_POST['selAlm']  ?? 0;
        $estado    = isset($_POST['chkEst']) ? 1 : 0;
        $this->modelo->update($id, $fecha, $empleado, $proveedor, $almacen, $estado);
        header('Location: /almaceneslibertad/public/?controller=registroentrada&action=listar');
        exit;
    }

    // Anulación lógica
    public function eliminar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->delete($id);
        header('Location: /almaceneslibertad/public/?controller=registroentrada&action=listar');
        exit;
    }

    public function habilita()
    {
        $limite = 10;
        $pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        if ($pagina < 1) $pagina = 1;
        $inicio = ($pagina - 1) * $limite;
        $totalRegistros = $this->modelo->countAll();
        $totalPaginas = ceil($totalRegistros / $limite);
        $entradas = $this->modelo->findAllPaginated($inicio, $limite);
        require_once __DIR__ . '/../views/registroentrada/habilitarregistroentrada.php';
    }

    public function habilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->enable($id);
        header('Location: /almaceneslibertad/public/?controller=registroentrada&action=habilita');
        exit;
    }

    public function deshabilitar()
    {
        $id = $_GET['id'] ?? 0;
        $this->modelo->disable($id);
        header('Location: /almaceneslibertad/public/?controller=registroentrada&action=habilita');
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>