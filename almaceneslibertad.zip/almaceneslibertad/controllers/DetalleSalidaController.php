<?php
require_once __DIR__ . '/../models/DetalleSalida.php';
require_once __DIR__ . '/../models/InventarioAlmacen.php';
require_once __DIR__ . '/../models/Producto.php';

class DetalleSalidaController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new DetalleSalida();
    }

    /*
     * listar() — Responde peticiones AJAX del modal de detalle de salida.
     * Devuelve JSON con las líneas del detalle para el nrosal recibido por GET.
     */
    public function listar()
    {
        header('Content-Type: application/json');
        $nrosal    = isset($_GET['nrosal']) ? (int) $_GET['nrosal'] : 0;
        $resultado = $this->modelo->findBySalida($nrosal);
        $filas     = [];
        $total     = 0;

        if ($resultado && $resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $filas[] = [
                    'nrodetsal' => $fila['nrodetsal'],
                    'codpro'    => $fila['codpro'],
                    'nompro'    => $fila['nompro'],
                    'cansal'    => $fila['cansal'],
                    'presal'    => number_format((float) $fila['presal'], 2),
                    'subtotal'  => number_format((float) $fila['subtotal'], 2),
                ];
                $total += (float) $fila['subtotal'];
            }
        }

        echo json_encode([
            'success' => true,
            'nrosal'  => $nrosal,
            'total'   => number_format($total, 2),
            'items'   => $filas,
        ]);
        exit;
    }

    /*
     * registrar() — Añade una línea al detalle y descuenta del inventario del almacén.
     * Recibe por POST: nrosal, codpro, cansal, presal, codalm.
     * VALIDACIÓN: verifica stock disponible antes de registrar.
     */
    public function registrar()
    {
        header('Content-Type: application/json');

        $nrosal = (int)   ($_POST['nrosal'] ?? 0);
        $codpro = (int)   ($_POST['codpro'] ?? 0);
        $cansal = (int)   ($_POST['cansal'] ?? 0);
        $presal = (float) ($_POST['presal'] ?? 0);
        $codalm = (int)   ($_POST['codalm'] ?? 0);

        if ($nrosal <= 0 || $codpro <= 0 || $cansal <= 0 || $presal <= 0) {
            echo json_encode(['success' => false, 'mensaje' => 'Datos inválidos.']);
            exit;
        }

        // Verificar stock disponible antes de registrar
        if ($codalm > 0) {
            $inv    = new InventarioAlmacen();
            $resInv = $inv->findByAlmacenProducto($codalm, $codpro);

            if (!$resInv || $resInv->num_rows === 0) {
                echo json_encode(['success' => false, 'mensaje' => 'Producto sin stock en este almacén.']);
                exit;
            }

            $filaInv = $resInv->fetch_assoc();
            if ((int) $filaInv['stockactual'] < $cansal) {
                echo json_encode([
                    'success' => false,
                    'mensaje' => 'Stock insuficiente. Disponible: ' . $filaInv['stockactual'],
                ]);
                exit;
            }

            // Insertar línea de detalle
            $ok = $this->modelo->add($cansal, $presal, $nrosal, $codpro);

            if ($ok) {
                $nuevoStock = (int) $filaInv['stockactual'] - $cansal;
                $inv->updateStockByAlmacenProducto($codalm, $codpro, $nuevoStock);
            }
        } else {
            $ok = $this->modelo->add($cansal, $presal, $nrosal, $codpro);
        }

        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Detalle registrado y stock descontado.' : 'Error al registrar el detalle.',
        ]);
        exit;
    }

    /*
     * eliminar() — Elimina una línea de detalle por su PK (nrodetsal).
     */
    public function eliminar()
    {
        header('Content-Type: application/json');
        $nrodetsal = (int) ($_GET['id'] ?? 0);
        $ok        = $this->modelo->deleteLinea($nrodetsal);
        echo json_encode([
            'success' => (bool) $ok,
            'mensaje' => $ok ? 'Línea eliminada.' : 'Error al eliminar la línea.',
        ]);
        exit;
    }

    public function menu()
    {
        require_once __DIR__ . '/../views/menuprincipal.php';
    }
}
?>
