<?php
require_once '../config/database.php';

class RegistroEntrada
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar entradas habilitadas con paginación (con JOINs a empleado, proveedor, almacén)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT re.nroent, re.fecent, re.estent, re.codemp, re.codprov, re.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       p.nomprov,
                       a.nomalm
                FROM registroentrada re
                INNER JOIN empleado  e ON re.codemp  = e.codemp
                INNER JOIN proveedor p ON re.codprov  = p.codprov
                INNER JOIN almacen   a ON re.codalm   = a.codalm
                WHERE re.estent = 1
                ORDER BY re.nroent DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar entradas habilitadas
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM registroentrada WHERE estent = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los registros de entrada con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT re.nroent, re.fecent, re.estent, re.codemp, re.codprov, re.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       p.nomprov,
                       a.nomalm
                FROM registroentrada re
                INNER JOIN empleado  e ON re.codemp  = e.codemp
                INNER JOIN proveedor p ON re.codprov  = p.codprov
                INNER JOIN almacen   a ON re.codalm   = a.codalm
                ORDER BY re.nroent DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los registros de entrada
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM registroentrada";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitados sin paginación
    public function findAllCustom()
    {
        $sql = "SELECT re.nroent, re.fecent, re.estent, re.codemp, re.codprov, re.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       p.nomprov,
                       a.nomalm
                FROM registroentrada re
                INNER JOIN empleado  e ON re.codemp  = e.codemp
                INNER JOIN proveedor p ON re.codprov  = p.codprov
                INNER JOIN almacen   a ON re.codalm   = a.codalm
                WHERE re.estent = 1
                ORDER BY re.nroent DESC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT re.nroent, re.fecent, re.estent, re.codemp, re.codprov, re.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       p.nomprov,
                       a.nomalm
                FROM registroentrada re
                INNER JOIN empleado  e ON re.codemp  = e.codemp
                INNER JOIN proveedor p ON re.codprov  = p.codprov
                INNER JOIN almacen   a ON re.codalm   = a.codalm
                ORDER BY re.nroent DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar cabecera de Entrada
     * Columnas reales en BD: fecent, codemp, codprov, codalm, estent
     * CORRECCIÓN: el modelo original usaba columnas inexistentes (fecregent, tipcomregent, etc.)
     * Tipos: fecent(s), codemp(i), codprov(i), codalm(i), estent(i) -> 'siiii'
     * Retorna el insert_id para luego insertar los detalles
     */
    public function add($fecha, $empleado, $proveedor, $almacen, $estado)
    {
        $sql = "INSERT INTO registroentrada (fecent, codemp, codprov, codalm, estent)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siiii', $fecha, $empleado, $proveedor, $almacen, $estado);
        if ($stmt->execute()) {
            return $this->xcon->insert_id;
        }
        return false;
    }

    // Buscar entrada por su número (nroent) con JOINs
    public function findById($id)
    {
        $sql = "SELECT re.nroent, re.fecent, re.estent, re.codemp, re.codprov, re.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       p.nomprov,
                       a.nomalm
                FROM registroentrada re
                INNER JOIN empleado  e ON re.codemp  = e.codemp
                INNER JOIN proveedor p ON re.codprov  = p.codprov
                INNER JOIN almacen   a ON re.codalm   = a.codalm
                WHERE re.nroent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar cabecera de Entrada
     * Tipos: fecent(s), codemp(i), codprov(i), codalm(i), estent(i), nroent(i) -> 'siiiii'
     */
    public function update($id, $fecha, $empleado, $proveedor, $almacen, $estado)
    {
        $sql = "UPDATE registroentrada SET
                    fecent  = ?, codemp  = ?, codprov = ?,
                    codalm  = ?, estent  = ?
                WHERE nroent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siiiii', $fecha, $empleado, $proveedor, $almacen, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación lógica (anulación)
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar registro de entrada
    public function enable($id)
    {
        $sql = "UPDATE registroentrada SET estent = 1 WHERE nroent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar/Anular registro de entrada
    public function disable($id)
    {
        $sql = "UPDATE registroentrada SET estent = 0 WHERE nroent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
