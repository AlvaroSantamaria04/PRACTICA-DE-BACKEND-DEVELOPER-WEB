<?php
require_once '../config/database.php';

class DetalleSalida
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // ── LISTADO CON JOIN (producto) ───────────────────────────────────────
    public function findBySalida($nrosal)
    {
        $sql = "SELECT ds.nrodetsal, ds.cansal, ds.presal, ds.nrosal, ds.codpro,
                       p.nompro,
                       (ds.cansal * ds.presal) AS subtotal
                FROM detallesalida ds
                INNER JOIN producto p ON ds.codpro = p.codpro
                WHERE ds.nrosal = ?
                ORDER BY ds.nrodetsal ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nrosal);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Todos los detalles con JOIN (reportes)
    public function findAll()
    {
        $sql = "SELECT ds.nrodetsal, ds.cansal, ds.presal, ds.nrosal, ds.codpro,
                       p.nompro,
                       (ds.cansal * ds.presal) AS subtotal
                FROM detallesalida ds
                INNER JOIN producto p ON ds.codpro = p.codpro
                ORDER BY ds.nrosal DESC, ds.nrodetsal ASC";
        return $this->xcon->query($sql);
    }

    // Paginación general
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql  = "SELECT ds.nrodetsal, ds.cansal, ds.presal, ds.nrosal, ds.codpro,
                        p.nompro,
                        (ds.cansal * ds.presal) AS subtotal
                 FROM detallesalida ds
                 INNER JOIN producto p ON ds.codpro = p.codpro
                 ORDER BY ds.nrodetsal DESC
                 LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar filas
    public function countAll()
    {
        $res = $this->xcon->query("SELECT COUNT(*) AS total FROM detallesalida");
        return $res->fetch_assoc()['total'];
    }

    // Buscar por nrosal (ID maestro)
    public function findById($nrosal)
    {
        $sql  = "SELECT ds.nrodetsal, ds.cansal, ds.presal, ds.nrosal, ds.codpro,
                        p.nompro
                 FROM detallesalida ds
                 INNER JOIN producto p ON ds.codpro = p.codpro
                 WHERE ds.nrosal = ?
                 ORDER BY ds.nrodetsal ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nrosal);
        $stmt->execute();
        return $stmt->get_result();
    }

    // ── REGISTRAR ────────────────────────────────────────────────────────
    // Tipos: cansal(i), presal(d), nrosal(i), codpro(i) → 'idii'
    public function add($cantidad, $precio, $nrosal, $codpro)
    {
        $sql  = "INSERT INTO detallesalida (cansal, presal, nrosal, codpro) VALUES (?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('idii', $cantidad, $precio, $nrosal, $codpro);
        return $stmt->execute();
    }

    // ── ACTUALIZAR ───────────────────────────────────────────────────────
    public function update($id, $cantidad, $precio, $nrosal, $codpro)
    {
        $sql  = "UPDATE detallesalida SET cansal = ?, presal = ?, nrosal = ?, codpro = ? WHERE nrodetsal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('idiii', $cantidad, $precio, $nrosal, $codpro, $id);
        return $stmt->execute();
    }

    // ── ELIMINAR (físico por nrosal — borra todo el bloque del maestro) ──
    public function delete($nrosal)
    {
        $sql  = "DELETE FROM detallesalida WHERE nrosal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nrosal);
        return $stmt->execute();
    }

    // Eliminar una línea individual por su PK
    public function deleteLinea($nrodetsal)
    {
        $sql  = "DELETE FROM detallesalida WHERE nrodetsal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nrodetsal);
        return $stmt->execute();
    }
}
?>
