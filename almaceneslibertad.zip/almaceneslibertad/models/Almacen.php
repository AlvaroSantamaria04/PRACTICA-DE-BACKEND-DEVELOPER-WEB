<?php
require_once '../config/database.php';

class Almacen
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // ── LISTADO BASE (SELECT con JOIN a sucursal) ─────────────────────────
    private function baseSelect(): string
    {
        return "SELECT a.codalm, a.nomalm, a.tipoalm, a.diralm, a.estalm, a.codsuc,
                       s.nomsuc
                FROM almacen a
                LEFT JOIN sucursal s ON a.codsuc = s.codsuc";
    }

    // Habilitados + paginación
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql  = $this->baseSelect() . " WHERE a.estalm = 1 ORDER BY a.nomalm ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar habilitados
    public function countAllCustom()
    {
        $res = $this->xcon->query("SELECT COUNT(*) AS total FROM almacen WHERE estalm = 1");
        return $res->fetch_assoc()['total'];
    }

    // Todos + paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql  = $this->baseSelect() . " ORDER BY a.codalm DESC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos
    public function countAll()
    {
        $res = $this->xcon->query("SELECT COUNT(*) AS total FROM almacen");
        return $res->fetch_assoc()['total'];
    }

    // Habilitados sin paginación (para selects/combos)
    public function findAllCustom()
    {
        return $this->xcon->query(
            $this->baseSelect() . " WHERE a.estalm = 1 ORDER BY a.nomalm ASC"
        );
    }

    // Todos sin paginación
    public function findAll()
    {
        return $this->xcon->query($this->baseSelect() . " ORDER BY a.codalm DESC");
    }

    // ── REGISTRAR ────────────────────────────────────────────────────────
    // CORRECCIÓN: codsuc puede ser NULL (almacén Central); se usa bind condicional
    public function add($nombre, $tipo, $direccion, $estado, $codsuc)
    {
        if ($tipo === 'Central' || $codsuc === null || $codsuc === '') {
            $codsuc = null;
        } else {
            $codsuc = (int) $codsuc;
        }

        $sql  = "INSERT INTO almacen (nomalm, tipoalm, diralm, estalm, codsuc) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        // MySQLi pasa NULL correctamente cuando la variable es null con tipo 'i'
        $stmt->bind_param('sssii', $nombre, $tipo, $direccion, $estado, $codsuc);
        return $stmt->execute();
    }

    // ── BUSCAR POR ID ────────────────────────────────────────────────────
    public function findById($id)
    {
        $sql  = $this->baseSelect() . " WHERE a.codalm = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    // ── ACTUALIZAR ───────────────────────────────────────────────────────
    // CORRECCIÓN: codsuc NULL si es Central o viene vacío
    public function update($id, $nombre, $tipo, $direccion, $estado, $codsuc)
    {
        if ($tipo === 'Central' || $codsuc === null || $codsuc === '') {
            $codsuc = null;
        } else {
            $codsuc = (int) $codsuc;
        }

        $sql  = "UPDATE almacen SET nomalm = ?, tipoalm = ?, diralm = ?, estalm = ?, codsuc = ? WHERE codalm = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sssiii', $nombre, $tipo, $direccion, $estado, $codsuc, $id);
        return $stmt->execute();
    }

    // ── ESTADO UNIFICADO ─────────────────────────────────────────────────
    public function changeStatus($id, $estado)
    {
        $nuevoEstado = ($estado == 1) ? 1 : 0;
        $sql  = "UPDATE almacen SET estalm = ? WHERE codalm = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $nuevoEstado, $id);
        return $stmt->execute();
    }

    public function delete($id)     { return $this->changeStatus($id, 0); }
    public function enable($id)     { return $this->changeStatus($id, 1); }
    public function disable($id)    { return $this->changeStatus($id, 0); }
}
?>
