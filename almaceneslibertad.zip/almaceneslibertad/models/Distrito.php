<?php
require_once '../config/database.php';

class Distrito {
    private $xcon;

    public function __construct() {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Verifica si el nombre ya existe (para registrar uno nuevo)
    public function verificarNombreExistente($nombre) {
        $sql = "SELECT coddis FROM distrito WHERE nomdis = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('s', $nombre);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Verifica si el nombre ya existe en OTRA fila (para actualizar)
    public function nombreYaExisteParaOtro($id, $nombre) {
        $sql = "SELECT coddis FROM distrito WHERE nomdis = ? AND coddis != ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Listar activos para el listado principal
    public function findAllCustomPaginated($inicio, $limite) {
        $sql = "SELECT * FROM distrito WHERE estdis = 1 ORDER BY CAST(coddis AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAllCustom() {
        $sql = "SELECT COUNT(*) AS total FROM distrito WHERE estdis = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos para el módulo de habilitación
    public function findAllPaginated($inicio, $limite) {
        $sql = "SELECT * FROM distrito ORDER BY CAST(coddis AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAll() {
        $sql = "SELECT COUNT(*) AS total FROM distrito";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    public function findById($id) {
        $sql = "SELECT * FROM distrito WHERE coddis = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function add($nombre, $estado) {
        $sql = "INSERT INTO distrito (nomdis, estdis) VALUES (?, ?)";
        // CORREGIDO: Ahora usa $this->xcon->prepare
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $estado);
        return $stmt->execute();
    }

    public function update($id, $nombre, $estado) {
        $sql = "UPDATE distrito SET nomdis = ?, estdis = ? WHERE coddis = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sii', $nombre, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación Lógica
    public function delete($id) {
        return $this->disable($id);
    }

    public function enable($id) {
        $sql = "UPDATE distrito SET estdis = 1 WHERE coddis = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    public function disable($id) {
        $sql = "UPDATE distrito SET estdis = 0 WHERE coddis = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}