<?php
require_once '../config/database.php';

class Traslado
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar traslados activos con paginación (con JOINs a almacenes y empleado)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT t.codtra, t.fectra, t.codalmorigen, t.codalmdestino, t.codemp, t.esttra,
                       ao.nomalm AS nomalmacen_origen,
                       ad.nomalm AS nomalmacen_destino,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado
                FROM traslado t
                INNER JOIN almacen ao ON t.codalmorigen  = ao.codalm
                INNER JOIN almacen ad ON t.codalmdestino = ad.codalm
                INNER JOIN empleado e ON t.codemp        = e.codemp
                WHERE t.esttra = 1
                ORDER BY t.fectra DESC, t.codtra DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar traslados activos
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM traslado WHERE esttra = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los traslados con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT t.codtra, t.fectra, t.codalmorigen, t.codalmdestino, t.codemp, t.esttra,
                       ao.nomalm AS nomalmacen_origen,
                       ad.nomalm AS nomalmacen_destino,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado
                FROM traslado t
                INNER JOIN almacen ao ON t.codalmorigen  = ao.codalm
                INNER JOIN almacen ad ON t.codalmdestino = ad.codalm
                INNER JOIN empleado e ON t.codemp        = e.codemp
                ORDER BY t.codtra DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los traslados
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM traslado";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar activos sin paginación
    public function findAllCustom()
    {
        $sql = "SELECT t.codtra, t.fectra, t.codalmorigen, t.codalmdestino, t.codemp, t.esttra,
                       ao.nomalm AS nomalmacen_origen,
                       ad.nomalm AS nomalmacen_destino,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado
                FROM traslado t
                INNER JOIN almacen ao ON t.codalmorigen  = ao.codalm
                INNER JOIN almacen ad ON t.codalmdestino = ad.codalm
                INNER JOIN empleado e ON t.codemp        = e.codemp
                WHERE t.esttra = 1
                ORDER BY t.codtra DESC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT t.codtra, t.fectra, t.codalmorigen, t.codalmdestino, t.codemp, t.esttra,
                       ao.nomalm AS nomalmacen_origen,
                       ad.nomalm AS nomalmacen_destino,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado
                FROM traslado t
                INNER JOIN almacen ao ON t.codalmorigen  = ao.codalm
                INNER JOIN almacen ad ON t.codalmdestino = ad.codalm
                INNER JOIN empleado e ON t.codemp        = e.codemp
                ORDER BY t.codtra DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar Cabecera de Traslado
     * Columnas reales en BD: fectra, codalmorigen, codalmdestino, codemp, esttra
     * CORRECCIÓN: el original usaba 'codalmorigan' (typo) en lugar de 'codalmorigen'
     * Tipos: fectra(s), codalmorigen(i), codalmdestino(i), codemp(i), esttra(i) -> 'siiii'
     * Retorna el insert_id para luego insertar los detalles
     */
    public function add($fecha, $almacenOrigen, $almacenDestino, $empleado, $estado)
    {
        $sql = "INSERT INTO traslado (fectra, codalmorigen, codalmdestino, codemp, esttra)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siiii', $fecha, $almacenOrigen, $almacenDestino, $empleado, $estado);
        if ($stmt->execute()) {
            return $this->xcon->insert_id;
        }
        return false;
    }

    // Buscar traslado por ID (con JOINs)
    public function findById($id)
    {
        $sql = "SELECT t.codtra, t.fectra, t.codalmorigen, t.codalmdestino, t.codemp, t.esttra,
                       ao.nomalm AS nomalmacen_origen,
                       ad.nomalm AS nomalmacen_destino,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado
                FROM traslado t
                INNER JOIN almacen ao ON t.codalmorigen  = ao.codalm
                INNER JOIN almacen ad ON t.codalmdestino = ad.codalm
                INNER JOIN empleado e ON t.codemp        = e.codemp
                WHERE t.codtra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar datos del Traslado
     * Tipos: fectra(s), codalmorigen(i), codalmdestino(i), codemp(i), esttra(i), codtra(i) -> 'siiiii'
     */
    public function update($id, $fecha, $almacenOrigen, $almacenDestino, $empleado, $estado)
    {
        $sql = "UPDATE traslado SET
                    fectra        = ?, codalmorigen  = ?,
                    codalmdestino = ?, codemp         = ?, esttra = ?
                WHERE codtra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siiiii', $fecha, $almacenOrigen, $almacenDestino, $empleado, $estado, $id);
        return $stmt->execute();
    }

    // Anulación lógica del traslado
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Activar traslado
    public function enable($id)
    {
        $sql = "UPDATE traslado SET esttra = 1 WHERE codtra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Anular/Deshabilitar traslado
    public function disable($id)
    {
        $sql = "UPDATE traslado SET esttra = 0 WHERE codtra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
