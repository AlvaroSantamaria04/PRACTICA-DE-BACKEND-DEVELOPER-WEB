<?php
require_once __DIR__ . '/../config/database.php';

class Marca
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Verifica si el nombre ya existe (para registrar uno nuevo)
    public function verificarNombreExistente($nombre)
    {
        $sql = "SELECT codmar FROM marca WHERE nommar = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('s', $nombre);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Verifica si el nombre ya existe en otra fila (para actualizar)
    public function nombreYaExisteParaOtro($id, $nombre)
    {
        $sql = "SELECT codmar FROM marca WHERE nommar = ? AND codmar != ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Listar activos para el listado principal
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT * FROM marca WHERE estmar = 1 ORDER BY CAST(codmar AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM marca WHERE estmar = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos activos (sin paginación) para select/combos
    public function findAllCustom()
    {
        $sql = "SELECT * FROM marca WHERE estmar = 1 ORDER BY CAST(codmar AS UNSIGNED) ASC";
        $resultado = $this->xcon->query($sql);
        return $resultado;
    }

    // Listar todas las marcas (sin paginación) para formularios de edición
    public function findAll()
    {
        $sql = "SELECT * FROM marca ORDER BY CAST(codmar AS UNSIGNED) ASC";
        return $this->xcon->query($sql);
    }

    // Listar todos para el módulo de habilitación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT * FROM marca ORDER BY CAST(codmar AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM marca";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    public function findById($id)
    {
        $sql = "SELECT * FROM marca WHERE codmar = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function add($nombre, $estado)
    {
        $sql = "INSERT INTO marca (nommar, estmar) VALUES (?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $estado);
        return $stmt->execute();
    }

    public function update($id, $nombre, $estado)
    {
        $sql = "UPDATE marca SET nommar = ?, estmar = ? WHERE codmar = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sii', $nombre, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación lógica
    public function delete($id)
    {
        return $this->disable($id);
    }

    public function enable($id)
    {
        $sql = "UPDATE marca SET estmar = 1 WHERE codmar = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    public function disable($id)
    {
        $sql = "UPDATE marca SET estmar = 0 WHERE codmar = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
