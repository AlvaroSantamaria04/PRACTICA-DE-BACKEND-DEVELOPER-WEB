<?php
require_once '../config/database.php';

class Producto
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar productos habilitados con paginación (con JOINs a categoría y marca)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT p.codpro, p.nompro, p.despre, p.prepro, p.canpro, p.estpro,
                       p.codcat, p.codmar,
                       c.nomcat,
                       m.nommar
                FROM producto p
                INNER JOIN categoria c ON p.codcat = c.codcat
                INNER JOIN marca m     ON p.codmar = m.codmar
                WHERE p.estpro = 1
                ORDER BY p.nompro ASC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar productos habilitados
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM producto WHERE estpro = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los productos con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT p.codpro, p.nompro, p.despre, p.prepro, p.canpro, p.estpro,
                       p.codcat, p.codmar,
                       c.nomcat,
                       m.nommar
                FROM producto p
                INNER JOIN categoria c ON p.codcat = c.codcat
                INNER JOIN marca m     ON p.codmar = m.codmar
                ORDER BY p.codpro DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los productos
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM producto";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitados sin paginación
    public function findAllCustom()
    {
        $sql = "SELECT p.codpro, p.nompro, p.despre, p.prepro, p.canpro, p.estpro,
                       p.codcat, p.codmar,
                       c.nomcat,
                       m.nommar
                FROM producto p
                INNER JOIN categoria c ON p.codcat = c.codcat
                INNER JOIN marca m     ON p.codmar = m.codmar
                WHERE p.estpro = 1
                ORDER BY p.nompro ASC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT p.codpro, p.nompro, p.despre, p.prepro, p.canpro, p.estpro,
                       p.codcat, p.codmar,
                       c.nomcat,
                       m.nommar
                FROM producto p
                INNER JOIN categoria c ON p.codcat = c.codcat
                INNER JOIN marca m     ON p.codmar = m.codmar
                ORDER BY p.codpro DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar Producto
     * CORRECCIÓN: se agregan los campos obligatorios 'despre' y 'canpro' que faltaban en el original
     * Columnas reales en BD: nompro, despre, prepro, canpro, estpro, codcat, codmar
     * Tipos: nompro(s), despre(s), prepro(d), canpro(i), estpro(i), codcat(i), codmar(i) -> 'ssdiiii'
     */
    public function add($nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca)
    {
        $sql = "INSERT INTO producto (nompro, despre, prepro, canpro, estpro, codcat, codmar)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ssdiiii', $nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca);
        return $stmt->execute();
    }

    // Buscar producto por ID (con LEFT JOIN para no fallar si categoría o marca no existen)
    public function findById($id)
    {
        $sql = "SELECT p.codpro, p.nompro, p.despre, p.prepro, p.canpro, p.estpro,
                       p.codcat, p.codmar,
                       c.nomcat,
                       m.nommar
                FROM producto p
                LEFT JOIN categoria c ON p.codcat = c.codcat
                LEFT JOIN marca m     ON p.codmar = m.codmar
                WHERE p.codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar Producto
     * CORRECCIÓN: se agregan 'despre' y 'canpro' que faltaban
     * Tipos: 'ssdiiii' + codpro final (i) -> 'ssdiiiii'
     */
    public function update($id, $nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca)
    {
        $sql = "UPDATE producto SET
                    nompro  = ?, despre  = ?, prepro = ?,
                    canpro  = ?, estpro  = ?, codcat = ?, codmar = ?
                WHERE codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ssdiiiii', $nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca, $id);
        return $stmt->execute();
    }

    // Eliminación lógica
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar producto
    public function enable($id)
    {
        $sql = "UPDATE producto SET estpro = 1 WHERE codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar producto
    public function disable($id)
    {
        $sql = "UPDATE producto SET estpro = 0 WHERE codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
