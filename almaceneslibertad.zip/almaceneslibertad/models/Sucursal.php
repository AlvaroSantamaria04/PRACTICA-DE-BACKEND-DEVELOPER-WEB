<?php
require_once '../config/database.php';

class Sucursal
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar sucursales habilitadas con paginación
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT * FROM sucursal WHERE estsuc = 1 ORDER BY nomsuc ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar sucursales habilitadas
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM sucursal WHERE estsuc = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todas las sucursales con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT * FROM sucursal ORDER BY codsuc DESC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todas las sucursales registradas
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM sucursal";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitadas sin paginación (Muy útil para llenar los selects en el formulario de Empleado)
    public function findAllCustom()
    {
        $sql = "SELECT * FROM sucursal WHERE estsuc = 1 ORDER BY nomsuc ASC";
        return $this->xcon->query($sql);
    }

    // Listar todas las sucursales sin paginación
    public function findAll()
    {
        $sql = "SELECT * FROM sucursal ORDER BY codsuc DESC";
        return $this->xcon->query($sql);
    }

    /* Registrar Sucursal
       Campos ordenados: nomsuc, dirsuc, telsuc, celsuc, corsuc, estsuc, coddis
       Tipos: 5 strings seguidos de 2 enteros -> 'sssssii'
    */
    public function add($nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito)
    {
        $sql = "INSERT INTO sucursal (nomsuc, dirsuc, telsuc, celsuc, corsuc, estsuc, coddis) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sssssii', $nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito);
        return $stmt->execute();
    }

    // Buscar sucursal por su código único (codsuc)
    public function findById($id)
    {
        $sql = "SELECT * FROM sucursal WHERE codsuc = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /* Actualizar Sucursal
       Tipos: 5 strings y 3 enteros (los 2 campos de datos + el ID codsuc al final) -> 'sssssiii'
    */
    public function update($id, $nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito)
    {
        $sql = "UPDATE sucursal SET nomsuc = ?, dirsuc = ?, telsuc = ?, celsuc = ?, corsuc = ?, estsuc = ?, coddis = ? WHERE codsuc = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sssssiii', $nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito, $id);
        return $stmt->execute();
    }

    // Eliminación lógica
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar sucursal
    public function enable($id)
    {
        $sql = "UPDATE sucursal SET estsuc = 1 WHERE codsuc = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar sucursal
    public function disable($id)
    {
        $sql = "UPDATE sucursal SET estsuc = 0 WHERE codsuc = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}