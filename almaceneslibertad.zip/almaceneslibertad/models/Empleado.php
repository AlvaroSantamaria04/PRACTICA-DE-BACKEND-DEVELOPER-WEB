<?php
require_once '../config/database.php';

class Empleado
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar empleados habilitados con paginación (con JOINs a tablas relacionadas)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT
                    e.codemp, e.nomemp, e.apepemp, e.apememp, e.docemp,
                    e.diremp, e.telemp, e.celemp, e.coremp, e.estemp,
                    e.coddis, e.codrol, e.codtipd, e.codsuc, e.codsex,
                    d.nomdis,
                    r.nomrol,
                    t.nomtipd,
                    s.nomsuc,
                    sx.nomsex
                FROM empleado e
                INNER JOIN distrito d    ON e.coddis  = d.coddis
                INNER JOIN rol r         ON e.codrol   = r.codrol
                INNER JOIN tipodocumento t ON e.codtipd = t.codtipd
                INNER JOIN sucursal s    ON e.codsuc   = s.codsuc
                INNER JOIN sexo sx       ON e.codsex   = sx.codsex
                WHERE e.estemp = 1
                ORDER BY e.apepemp ASC, e.apememp ASC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar empleados habilitados
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM empleado WHERE estemp = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los empleados con paginación (con JOINs)
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT
                    e.codemp, e.nomemp, e.apepemp, e.apememp, e.docemp,
                    e.diremp, e.telemp, e.celemp, e.coremp, e.estemp,
                    e.coddis, e.codrol, e.codtipd, e.codsuc, e.codsex,
                    d.nomdis,
                    r.nomrol,
                    t.nomtipd,
                    s.nomsuc,
                    sx.nomsex
                FROM empleado e
                INNER JOIN distrito d    ON e.coddis  = d.coddis
                INNER JOIN rol r         ON e.codrol   = r.codrol
                INNER JOIN tipodocumento t ON e.codtipd = t.codtipd
                INNER JOIN sucursal s    ON e.codsuc   = s.codsuc
                INNER JOIN sexo sx       ON e.codsex   = sx.codsex
                ORDER BY e.codemp DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los empleados
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM empleado";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitados sin paginación (para selects/combos)
    public function findAllCustom()
    {
        $sql = "SELECT
                    e.codemp, e.nomemp, e.apepemp, e.apememp, e.docemp,
                    e.diremp, e.telemp, e.celemp, e.coremp, e.estemp,
                    e.coddis, e.codrol, e.codtipd, e.codsuc, e.codsex,
                    d.nomdis,
                    r.nomrol,
                    t.nomtipd,
                    s.nomsuc,
                    sx.nomsex
                FROM empleado e
                INNER JOIN distrito d    ON e.coddis  = d.coddis
                INNER JOIN rol r         ON e.codrol   = r.codrol
                INNER JOIN tipodocumento t ON e.codtipd = t.codtipd
                INNER JOIN sucursal s    ON e.codsuc   = s.codsuc
                INNER JOIN sexo sx       ON e.codsex   = sx.codsex
                WHERE e.estemp = 1
                ORDER BY e.apepemp ASC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT
                    e.codemp, e.nomemp, e.apepemp, e.apememp, e.docemp,
                    e.diremp, e.telemp, e.celemp, e.coremp, e.estemp,
                    e.coddis, e.codrol, e.codtipd, e.codsuc, e.codsex,
                    d.nomdis,
                    r.nomrol,
                    t.nomtipd,
                    s.nomsuc,
                    sx.nomsex
                FROM empleado e
                INNER JOIN distrito d    ON e.coddis  = d.coddis
                INNER JOIN rol r         ON e.codrol   = r.codrol
                INNER JOIN tipodocumento t ON e.codtipd = t.codtipd
                INNER JOIN sucursal s    ON e.codsuc   = s.codsuc
                INNER JOIN sexo sx       ON e.codsex   = sx.codsex
                ORDER BY e.codemp DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar Empleado
     * Columnas reales en BD: nomemp, apepemp, apememp, docemp, diremp, telemp,
     *                         celemp, coremp, estemp, coddis, codrol, codtipd, codsuc, codsex
     * Tipos: s=string, i=integer  -> 'sssssssssiiiiii'
     */
    public function add($nombre, $apePat, $apeMat, $documento, $direccion,
                        $telefono, $celular, $correo, $estado,
                        $distrito, $rol, $tipoDoc, $sucursal, $sexo)
    {
        $sql = "INSERT INTO empleado
                    (nomemp, apepemp, apememp, docemp, diremp, telemp,
                     celemp, coremp, estemp, coddis, codrol, codtipd, codsuc, codsex)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sssssssssiiiiii',
            $nombre, $apePat, $apeMat, $documento, $direccion,
            $telefono, $celular, $correo, $estado,
            $distrito, $rol, $tipoDoc, $sucursal, $sexo);
        return $stmt->execute();
    }

    // Buscar empleado por ID (con JOINs)
    public function findById($id)
    {
        $sql = "SELECT
                    e.codemp, e.nomemp, e.apepemp, e.apememp, e.docemp,
                    e.diremp, e.telemp, e.celemp, e.coremp, e.estemp,
                    e.coddis, e.codrol, e.codtipd, e.codsuc, e.codsex,
                    d.nomdis,
                    r.nomrol,
                    t.nomtipd,
                    s.nomsuc,
                    sx.nomsex
                FROM empleado e
                INNER JOIN distrito d    ON e.coddis  = d.coddis
                INNER JOIN rol r         ON e.codrol   = r.codrol
                INNER JOIN tipodocumento t ON e.codtipd = t.codtipd
                INNER JOIN sucursal s    ON e.codsuc   = s.codsuc
                INNER JOIN sexo sx       ON e.codsex   = sx.codsex
                WHERE e.codemp = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar Empleado
     * Tipos: 'sssssssssiiiiii' + id final (i) -> 'sssssssssiiiiiii'
     */
    public function update($id, $nombre, $apePat, $apeMat, $documento, $direccion,
                           $telefono, $celular, $correo, $estado,
                           $distrito, $rol, $tipoDoc, $sucursal, $sexo)
    {
        $sql = "UPDATE empleado SET
                    nomemp   = ?, apepemp = ?, apememp = ?, docemp  = ?,
                    diremp   = ?, telemp  = ?, celemp  = ?, coremp  = ?,
                    estemp   = ?, coddis  = ?, codrol  = ?, codtipd = ?,
                    codsuc   = ?, codsex  = ?
                WHERE codemp = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ssssssssiiiiiiii',
            $nombre, $apePat, $apeMat, $documento, $direccion,
            $telefono, $celular, $correo, $estado,
            $distrito, $rol, $tipoDoc, $sucursal, $sexo, $id);
        return $stmt->execute();
    }

    // Eliminación lógica
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar empleado
    public function enable($id)
    {
        $sql = "UPDATE empleado SET estemp = 1 WHERE codemp = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar empleado
    public function disable($id)
    {
        $sql = "UPDATE empleado SET estemp = 0 WHERE codemp = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Login del sistema
    public function login($usuario, $clave)
    {
        $sql = "SELECT e.codemp, e.nomemp, e.apepemp, e.apememp,
                       e.coremp, e.codrol, r.nomrol
                FROM empleado e
                INNER JOIN rol r ON e.codrol = r.codrol
                WHERE e.coremp = ? AND e.celemp = ? AND e.estemp = 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ss', $usuario, $clave);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->fetch_assoc();
    }
}
?>
