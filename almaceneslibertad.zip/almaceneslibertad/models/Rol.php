<?php
require_once '../config/database.php';

class Rol {
    private $xcon;

    public function __construct() {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Verifica si el nombre del rol ya existe (para registrar uno nuevo)
    public function verificarNombreExistente($nombre) {
        $sql = "SELECT codrol FROM rol WHERE nomrol = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('s', $nombre);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Verifica si el nombre del rol ya existe en OTRA fila (para actualizar)
    public function nombreYaExisteParaOtro($id, $nombre) {
        $sql = "SELECT codrol FROM rol WHERE nomrol = ? AND codrol != ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Listar activos para el listado principal
    public function findAllCustomPaginated($inicio, $limite) {
        $sql = "SELECT * FROM rol WHERE estrol = 1 ORDER BY CAST(codrol AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAllCustom() {
        $sql = "SELECT COUNT(*) AS total FROM rol WHERE estrol = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos para el módulo de habilitación
    public function findAllPaginated($inicio, $limite) {
        $sql = "SELECT * FROM rol ORDER BY CAST(codrol AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAll() {
        $sql = "SELECT COUNT(*) AS total FROM rol";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    public function findById($id) {
        $sql = "SELECT * FROM rol WHERE codrol = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function add($nombre, $estado) {
        $sql = "INSERT INTO rol (nomrol, estrol) VALUES (?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $estado);
        return $stmt->execute();
    }

    public function update($id, $nombre, $estado) {
        $sql = "UPDATE rol SET nomrol = ?, estrol = ? WHERE codrol = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sii', $nombre, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación Lógica
    public function delete($id) {
        return $this->disable($id);
    }

    public function enable($id) {
        $sql = "UPDATE rol SET estrol = 1 WHERE codrol = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    public function disable($id) {
        $sql = "UPDATE rol SET estrol = 0 WHERE codrol = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}