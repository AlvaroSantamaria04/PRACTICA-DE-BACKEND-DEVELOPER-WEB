<?php
require_once '../config/database.php';

class InventarioAlmacen
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar todo el inventario con paginación (con JOINs a almacén y producto)
    // CORRECCIÓN: la tabla NO tiene campo de estado; se listan todos los registros
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT i.codinv, i.codalm, i.codpro, i.stockactual,
                       a.nomalm,
                       p.nompro
                FROM inventarioalmacen i
                INNER JOIN almacen a  ON i.codalm = a.codalm
                INNER JOIN producto p ON i.codpro  = p.codpro
                ORDER BY i.codinv DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los registros de inventario
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM inventarioalmacen";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todo sin paginación (útil para reportes)
    public function findAll()
    {
        $sql = "SELECT i.codinv, i.codalm, i.codpro, i.stockactual,
                       a.nomalm,
                       p.nompro
                FROM inventarioalmacen i
                INNER JOIN almacen a  ON i.codalm = a.codalm
                INNER JOIN producto p ON i.codpro  = p.codpro
                ORDER BY a.nomalm ASC, p.nompro ASC";
        return $this->xcon->query($sql);
    }

    // Buscar registro de inventario por su ID (codinv)
    public function findById($id)
    {
        $sql = "SELECT i.codinv, i.codalm, i.codpro, i.stockactual,
                       a.nomalm,
                       p.nompro
                FROM inventarioalmacen i
                INNER JOIN almacen a  ON i.codalm = a.codalm
                INNER JOIN producto p ON i.codpro  = p.codpro
                WHERE i.codinv = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * MÉTODO ESPECIAL: Buscar stock por Almacén y Producto
     * Indispensable para validar disponibilidad antes de una Salida o Traslado
     */
    public function findByAlmacenProducto($almacen, $producto)
    {
        $sql = "SELECT i.codinv, i.codalm, i.codpro, i.stockactual,
                       a.nomalm,
                       p.nompro
                FROM inventarioalmacen i
                INNER JOIN almacen a  ON i.codalm = a.codalm
                INNER JOIN producto p ON i.codpro  = p.codpro
                WHERE i.codalm = ? AND i.codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $almacen, $producto);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Registrar relación en el Inventario
     * Columnas reales en BD: codalm, codpro, stockactual
     * CORRECCIÓN: el original usaba columnas inexistentes (stoinvalm, estinvalm, codinvalm)
     * La combinación (codalm, codpro) es UNIQUE en la BD
     * Tipos: codalm(i), codpro(i), stockactual(i) -> 'iii'
     */
    public function add($almacen, $producto, $stock)
    {
        $sql = "INSERT INTO inventarioalmacen (codalm, codpro, stockactual)
                VALUES (?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('iii', $almacen, $producto, $stock);
        return $stmt->execute();
    }

    /*
     * Actualizar el stock de un registro de inventario
     * Tipos: stockactual(i), codinv(i) -> 'ii'
     */
    public function update($id, $stock)
    {
        $sql = "UPDATE inventarioalmacen SET stockactual = ? WHERE codinv = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $stock, $id);
        return $stmt->execute();
    }

    /*
     * MÉTODO ESPECIAL: Actualizar stock directamente por almacén y producto
     * Se usa después de cada entrada, salida o traslado
     */
    public function updateStockByAlmacenProducto($almacen, $producto, $stock)
    {
        $sql = "UPDATE inventarioalmacen SET stockactual = ? WHERE codalm = ? AND codpro = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('iii', $stock, $almacen, $producto);
        return $stmt->execute();
    }

    // Eliminar físicamente un registro de inventario (no hay eliminación lógica; no hay campo estado)
    public function delete($id)
    {
        $sql = "DELETE FROM inventarioalmacen WHERE codinv = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
