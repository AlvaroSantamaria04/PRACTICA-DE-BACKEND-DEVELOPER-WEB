<?php
require_once '../config/database.php';

class Sexo {
    private $xcon;

    public function __construct() {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Verifica si el nombre ya existe (para registrar uno nuevo)
    public function verificarNombreExistente($nombre) {
        $sql = "SELECT codsex FROM sexo WHERE nomsex = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('s', $nombre);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Verifica si el nombre ya existe en OTRA fila (para actualizar)
    public function nombreYaExisteParaOtro($id, $nombre) {
        $sql = "SELECT codsex FROM sexo WHERE nomsex = ? AND codsex != ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->num_rows > 0;
    }

    // Listar activos para el listado principal
    public function findAllCustomPaginated($inicio, $limite) {
        $sql = "SELECT * FROM sexo WHERE estsex = 1 ORDER BY CAST(codsex AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAllCustom() {
        $sql = "SELECT COUNT(*) AS total FROM sexo WHERE estsex = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos para el módulo de habilitación
    public function findAllPaginated($inicio, $limite) {
        $sql = "SELECT * FROM sexo ORDER BY CAST(codsex AS UNSIGNED) ASC LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function countAll() {
        $sql = "SELECT COUNT(*) AS total FROM sexo";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    public function findById($id) {
        $sql = "SELECT * FROM sexo WHERE codsex = ? LIMIT 1";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function add($nombre, $estado) {
        $sql = "INSERT INTO sexo (nomsex, estsex) VALUES (?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('si', $nombre, $estado);
        return $stmt->execute();
    }

    public function update($id, $nombre, $estado) {
        $sql = "UPDATE sexo SET nomsex = ?, estsex = ? WHERE codsex = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('sii', $nombre, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación Lógica
    public function delete($id) {
        return $this->disable($id);
    }

    public function enable($id) {
        $sql = "UPDATE sexo SET estsex = 1 WHERE codsex = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    public function disable($id) {
        $sql = "UPDATE sexo SET estsex = 0 WHERE codsex = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}