<?php
require_once '../config/database.php';

class RegistroSalida
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar salidas habilitadas con paginación (con JOINs a empleado y almacén)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT rs.nrosal, rs.fecsal, rs.estsal, rs.codemp, rs.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       a.nomalm
                FROM registrosalida rs
                INNER JOIN empleado e ON rs.codemp = e.codemp
                INNER JOIN almacen  a ON rs.codalm  = a.codalm
                WHERE rs.estsal = 1
                ORDER BY rs.nrosal DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar salidas habilitadas
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM registrosalida WHERE estsal = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los registros de salida con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT rs.nrosal, rs.fecsal, rs.estsal, rs.codemp, rs.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       a.nomalm
                FROM registrosalida rs
                INNER JOIN empleado e ON rs.codemp = e.codemp
                INNER JOIN almacen  a ON rs.codalm  = a.codalm
                ORDER BY rs.nrosal DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los registros de salida
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM registrosalida";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitados sin paginación
    public function findAllCustom()
    {
        $sql = "SELECT rs.nrosal, rs.fecsal, rs.estsal, rs.codemp, rs.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       a.nomalm
                FROM registrosalida rs
                INNER JOIN empleado e ON rs.codemp = e.codemp
                INNER JOIN almacen  a ON rs.codalm  = a.codalm
                WHERE rs.estsal = 1
                ORDER BY rs.nrosal DESC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT rs.nrosal, rs.fecsal, rs.estsal, rs.codemp, rs.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       a.nomalm
                FROM registrosalida rs
                INNER JOIN empleado e ON rs.codemp = e.codemp
                INNER JOIN almacen  a ON rs.codalm  = a.codalm
                ORDER BY rs.nrosal DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar cabecera de Salida
     * Columnas reales en BD: fecsal, codemp, codalm, estsal
     * CORRECCIÓN: el original usaba columnas inexistentes (fecregsal, codcli, estregsal, etc.)
     * Tipos: fecsal(s), codemp(i), codalm(i), estsal(i) -> 'siii'
     * Retorna el insert_id para luego insertar los detalles
     */
    public function add($fecha, $empleado, $almacen, $estado)
    {
        $sql = "INSERT INTO registrosalida (fecsal, codemp, codalm, estsal)
                VALUES (?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siii', $fecha, $empleado, $almacen, $estado);
        if ($stmt->execute()) {
            return $this->xcon->insert_id;
        }
        return false;
    }

    // Buscar salida por número (nrosal) con JOINs
    public function findById($id)
    {
        $sql = "SELECT rs.nrosal, rs.fecsal, rs.estsal, rs.codemp, rs.codalm,
                       CONCAT(e.apepemp, ' ', e.apememp, ', ', e.nomemp) AS nomempleado,
                       a.nomalm
                FROM registrosalida rs
                INNER JOIN empleado e ON rs.codemp = e.codemp
                INNER JOIN almacen  a ON rs.codalm  = a.codalm
                WHERE rs.nrosal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar cabecera de Salida
     * Tipos: fecsal(s), codemp(i), codalm(i), estsal(i), nrosal(i) -> 'siiii'
     */
    public function update($id, $fecha, $empleado, $almacen, $estado)
    {
        $sql = "UPDATE registrosalida SET
                    fecsal = ?, codemp = ?, codalm = ?, estsal = ?
                WHERE nrosal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('siiii', $fecha, $empleado, $almacen, $estado, $id);
        return $stmt->execute();
    }

    // Eliminación lógica (anulación)
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar registro de salida
    public function enable($id)
    {
        $sql = "UPDATE registrosalida SET estsal = 1 WHERE nrosal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar/Anular registro de salida
    public function disable($id)
    {
        $sql = "UPDATE registrosalida SET estsal = 0 WHERE nrosal = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
