<?php
require_once '../config/database.php';

class DetalleEntrada
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // ── LISTADO CON JOIN (producto) ───────────────────────────────────────
    // Todos los detalles de una Entrada específica, con nombre de producto
    public function findByEntrada($nroent)
    {
        $sql = "SELECT de.nrodetent, de.canent, de.preent, de.nroent, de.codpro,
                       p.nompro,
                       (de.canent * de.preent) AS subtotal
                FROM detalleentrada de
                INNER JOIN producto p ON de.codpro = p.codpro
                WHERE de.nroent = ?
                ORDER BY de.nrodetent ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nroent);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Todos los detalles con JOIN (para reportes generales)
    public function findAll()
    {
        $sql = "SELECT de.nrodetent, de.canent, de.preent, de.nroent, de.codpro,
                       p.nompro,
                       (de.canent * de.preent) AS subtotal
                FROM detalleentrada de
                INNER JOIN producto p ON de.codpro = p.codpro
                ORDER BY de.nroent DESC, de.nrodetent ASC";
        return $this->xcon->query($sql);
    }

    // Paginación general
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql  = "SELECT de.nrodetent, de.canent, de.preent, de.nroent, de.codpro,
                        p.nompro,
                        (de.canent * de.preent) AS subtotal
                 FROM detalleentrada de
                 INNER JOIN producto p ON de.codpro = p.codpro
                 ORDER BY de.nrodetent DESC
                 LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar filas
    public function countAll()
    {
        $res = $this->xcon->query("SELECT COUNT(*) AS total FROM detalleentrada");
        return $res->fetch_assoc()['total'];
    }

    // Buscar por PK del detalle (nrodetent)
    public function findById($nroent)
    {
        $sql  = "SELECT de.nrodetent, de.canent, de.preent, de.nroent, de.codpro,
                        p.nompro
                 FROM detalleentrada de
                 INNER JOIN producto p ON de.codpro = p.codpro
                 WHERE de.nroent = ?
                 ORDER BY de.nrodetent ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nroent);
        $stmt->execute();
        return $stmt->get_result();
    }

    // ── REGISTRAR ────────────────────────────────────────────────────────
    // Tipos: canent(i), preent(d), nroent(i), codpro(i) → 'idii'
    public function add($cantidad, $precio, $nroent, $codpro)
    {
        $sql  = "INSERT INTO detalleentrada (canent, preent, nroent, codpro) VALUES (?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('idii', $cantidad, $precio, $nroent, $codpro);
        return $stmt->execute();
    }

    // ── ACTUALIZAR ───────────────────────────────────────────────────────
    public function update($id, $cantidad, $precio, $nroent, $codpro)
    {
        $sql  = "UPDATE detalleentrada SET canent = ?, preent = ?, nroent = ?, codpro = ? WHERE nrodetent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('idiii', $cantidad, $precio, $nroent, $codpro, $id);
        return $stmt->execute();
    }

    // ── ELIMINAR (físico por nroent — borra todo el bloque del maestro) ──
    public function delete($nroent)
    {
        $sql  = "DELETE FROM detalleentrada WHERE nroent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nroent);
        return $stmt->execute();
    }

    // Eliminar una línea individual por su PK
    public function deleteLinea($nrodetent)
    {
        $sql  = "DELETE FROM detalleentrada WHERE nrodetent = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $nrodetent);
        return $stmt->execute();
    }
}
?>
