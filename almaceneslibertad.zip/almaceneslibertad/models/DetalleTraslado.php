<?php
require_once '../config/database.php';

class DetalleTraslado
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // ── LISTADO CON JOIN (producto) ───────────────────────────────────────
    public function findByTraslado($codtra)
    {
        $sql = "SELECT dt.coddettra, dt.codtra, dt.codpro, dt.cantra,
                       p.nompro
                FROM detalletraslado dt
                INNER JOIN producto p ON dt.codpro = p.codpro
                WHERE dt.codtra = ?
                ORDER BY dt.coddettra ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $codtra);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Todos los detalles con JOIN (reportes)
    public function findAll()
    {
        $sql = "SELECT dt.coddettra, dt.codtra, dt.codpro, dt.cantra,
                       p.nompro
                FROM detalletraslado dt
                INNER JOIN producto p ON dt.codpro = p.codpro
                ORDER BY dt.codtra DESC, dt.coddettra ASC";
        return $this->xcon->query($sql);
    }

    // Paginación general
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql  = "SELECT dt.coddettra, dt.codtra, dt.codpro, dt.cantra,
                        p.nompro
                 FROM detalletraslado dt
                 INNER JOIN producto p ON dt.codpro = p.codpro
                 ORDER BY dt.coddettra DESC
                 LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar filas
    public function countAll()
    {
        $res = $this->xcon->query("SELECT COUNT(*) AS total FROM detalletraslado");
        return $res->fetch_assoc()['total'];
    }

    // Buscar por codtra (ID maestro)
    public function findById($codtra)
    {
        $sql  = "SELECT dt.coddettra, dt.codtra, dt.codpro, dt.cantra,
                        p.nompro
                 FROM detalletraslado dt
                 INNER JOIN producto p ON dt.codpro = p.codpro
                 WHERE dt.codtra = ?
                 ORDER BY dt.coddettra ASC";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $codtra);
        $stmt->execute();
        return $stmt->get_result();
    }

    // ── REGISTRAR ────────────────────────────────────────────────────────
    // Tipos: codtra(i), codpro(i), cantra(i) → 'iii'
    public function add($codtra, $codpro, $cantidad)
    {
        $sql  = "INSERT INTO detalletraslado (codtra, codpro, cantra) VALUES (?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('iii', $codtra, $codpro, $cantidad);
        return $stmt->execute();
    }

    // ── ACTUALIZAR ───────────────────────────────────────────────────────
    public function update($id, $codtra, $codpro, $cantidad)
    {
        $sql  = "UPDATE detalletraslado SET codtra = ?, codpro = ?, cantra = ? WHERE coddettra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('iiii', $codtra, $codpro, $cantidad, $id);
        return $stmt->execute();
    }

    // ── ELIMINAR (físico por codtra — borra todo el bloque del maestro) ──
    public function delete($codtra)
    {
        $sql  = "DELETE FROM detalletraslado WHERE codtra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $codtra);
        return $stmt->execute();
    }

    // Eliminar una línea individual por su PK
    public function deleteLinea($coddettra)
    {
        $sql  = "DELETE FROM detalletraslado WHERE coddettra = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $coddettra);
        return $stmt->execute();
    }
}
?>
