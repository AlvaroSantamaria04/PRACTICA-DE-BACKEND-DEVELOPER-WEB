<?php
require_once '../config/database.php';

class Proveedor
{
    private $xcon;

    public function __construct()
    {
        $db = new Conexion();
        $this->xcon = $db->Conectar();
    }

    // Listar proveedores habilitados con paginación (JOIN a distrito)
    public function findAllCustomPaginated($inicio, $limite)
    {
        $sql = "SELECT p.codprov, p.nomprov, p.repprov, p.dirprov, p.telprov,
                       p.celprov, p.corprov, p.estprov, p.coddis,
                       d.nomdis
                FROM proveedor p
                INNER JOIN distrito d ON p.coddis = d.coddis
                WHERE p.estprov = 1
                ORDER BY p.nomprov ASC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar proveedores habilitados
    public function countAllCustom()
    {
        $sql = "SELECT COUNT(*) AS total FROM proveedor WHERE estprov = 1";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar todos los proveedores con paginación
    public function findAllPaginated($inicio, $limite)
    {
        $sql = "SELECT p.codprov, p.nomprov, p.repprov, p.dirprov, p.telprov,
                       p.celprov, p.corprov, p.estprov, p.coddis,
                       d.nomdis
                FROM proveedor p
                INNER JOIN distrito d ON p.coddis = d.coddis
                ORDER BY p.codprov DESC
                LIMIT ?, ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ii', $inicio, $limite);
        $stmt->execute();
        return $stmt->get_result();
    }

    // Contar todos los proveedores
    public function countAll()
    {
        $sql = "SELECT COUNT(*) AS total FROM proveedor";
        $resultado = $this->xcon->query($sql);
        $fila = $resultado->fetch_assoc();
        return $fila['total'];
    }

    // Listar habilitados sin paginación (para selects)
    public function findAllCustom()
    {
        $sql = "SELECT p.codprov, p.nomprov, p.repprov, p.dirprov, p.telprov,
                       p.celprov, p.corprov, p.estprov, p.coddis,
                       d.nomdis
                FROM proveedor p
                INNER JOIN distrito d ON p.coddis = d.coddis
                WHERE p.estprov = 1
                ORDER BY p.nomprov ASC";
        return $this->xcon->query($sql);
    }

    // Listar todos sin paginación
    public function findAll()
    {
        $sql = "SELECT p.codprov, p.nomprov, p.repprov, p.dirprov, p.telprov,
                       p.celprov, p.corprov, p.estprov, p.coddis,
                       d.nomdis
                FROM proveedor p
                INNER JOIN distrito d ON p.coddis = d.coddis
                ORDER BY p.codprov DESC";
        return $this->xcon->query($sql);
    }

    /*
     * Registrar Proveedor
     * Columnas reales en BD: nomprov, repprov, dirprov, telprov, celprov, corprov, estprov, coddis
     * CORRECCIÓN: el modelo original usaba columnas inventadas (razsocprov, numdocprov, codtipdoc)
     * Tipos: nomprov(s), repprov(s), dirprov(s), telprov(s), celprov(s), corprov(s), estprov(i), coddis(i)
     *        -> 'ssssssii'
     */
    public function add($nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito)
    {
        $sql = "INSERT INTO proveedor (nomprov, repprov, dirprov, telprov, celprov, corprov, estprov, coddis)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ssssssii', $nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito);
        return $stmt->execute();
    }

    // Buscar proveedor por ID (con JOIN)
    public function findById($id)
    {
        $sql = "SELECT p.codprov, p.nomprov, p.repprov, p.dirprov, p.telprov,
                       p.celprov, p.corprov, p.estprov, p.coddis,
                       d.nomdis
                FROM proveedor p
                INNER JOIN distrito d ON p.coddis = d.coddis
                WHERE p.codprov = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result();
    }

    /*
     * Actualizar Proveedor
     * Tipos: 'ssssssii' + codprov final (i) -> 'ssssssiiii'  (corregido: 'ssssssiii')
     */
    public function update($id, $nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito)
    {
        $sql = "UPDATE proveedor SET
                    nomprov = ?, repprov = ?, dirprov = ?,
                    telprov = ?, celprov = ?, corprov = ?,
                    estprov = ?, coddis  = ?
                WHERE codprov = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('ssssssiii', $nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito, $id);
        return $stmt->execute();
    }

    // Eliminación lógica
    public function delete($id)
    {
        return $this->disable($id);
    }

    // Habilitar proveedor
    public function enable($id)
    {
        $sql = "UPDATE proveedor SET estprov = 1 WHERE codprov = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    // Deshabilitar proveedor
    public function disable($id)
    {
        $sql = "UPDATE proveedor SET estprov = 0 WHERE codprov = ?";
        $stmt = $this->xcon->prepare($sql);
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
?>
