<!doctype html>
<html lang="es" style="height: 100%;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Registrar Tipo Documento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f4f8 !important;
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .form-container {
            background: #ffffff;
            border-radius: 16px;
            padding: 30px;
            border: 1px solid #d1d9e6;
            box-shadow: 0 10px 30px rgba(0, 50, 100, 0.1);
            margin-top: 2rem;
        }

        h1 {
            color: #1e293b;
            font-weight: 800;
        }

        .btn {
            border-radius: 8px;
            font-weight: 600;
            padding: 10px 20px;
            transition: all 0.3s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <?php include __DIR__ . '/../templates/menu.php'; ?>

    <div class="container" style="flex: 1;">
        <div class="form-container col-lg-8 mx-auto">
            <h1 class="mb-4"><i class="bi bi-plus-circle-fill text-primary"></i> Registrar Nuevo Tipo de Documento</h1>

            <form action="/almaceneslibertad/public/?controller=tipodocumento&action=registrar" method="post">
                <div class="mb-3">
                    <label for="txtNom" class="form-label fw-bold">Nombre del Tipo de Documento:</label>
                    <input type="text" class="form-control" id="txtNom" name="txtNom"
                        placeholder="Ejemplo: DNI, Pasaporte, RUC, Carnet de Extranjería" required>
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="chkEst" name="chkEst" checked>
                        <label class="form-check-label fw-bold" for="chkEst">Habilitado</label>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Registrar</button>
                    <a href="/almaceneslibertad/public/?controller=tipodocumento&action=listar" class="btn btn-dark"><i class="bi bi-arrow-left"></i> Regresar</a>
                </div>
            </form>
        </div>
    </div>

    <?php include __DIR__ . '/../templates/pie.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>