<?php
// Vista: habilitarempleado.php
?>