<?php
// Vista: registrarempleado.php
?>