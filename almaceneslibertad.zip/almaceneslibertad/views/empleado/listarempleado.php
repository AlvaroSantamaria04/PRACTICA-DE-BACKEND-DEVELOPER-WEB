<?php
// Vista: listarempleado.php
?>