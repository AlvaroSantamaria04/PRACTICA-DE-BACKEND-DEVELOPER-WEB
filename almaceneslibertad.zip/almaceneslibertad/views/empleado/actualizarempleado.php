<?php
// Vista: actualizarempleado.php
?>