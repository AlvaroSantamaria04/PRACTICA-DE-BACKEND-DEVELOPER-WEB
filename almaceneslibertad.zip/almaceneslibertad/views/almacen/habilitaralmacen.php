<?php
// 1. Incluir tu archivo de conexión a la base de datos
// Ajusta la ruta de acuerdo a la estructura de carpetas de tu proyecto
require_once __DIR__ . '/../../config/conexion.php'; 

// 2. Capturar y validar los parámetros enviados por la URL ($_GET)
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$estado = isset($_GET['estado']) ? (int)$_GET['estado'] : 0;
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// 3. Validar que el ID sea correcto y que el estado sea estrictamente 0 o 1
if ($id > 0 && ($estado === 0 || $estado === 1)) {
    
    // Asumiendo que tu objeto de conexión se llama $db o $conexion
    // Modificamos la columna 'estpro' usando el identificador 'codpro'
    $sql = "UPDATE producto SET estpro = ? WHERE codpro = ?";
    
    if ($stmt = $db->prepare($sql)) {
        // "ii" -> El estado es un entero (0 o 1) y el ID también es un entero
        $stmt->bind_param("ii", $estado, $id);
        $stmt->execute();
        $stmt->close();
    }
}

// 4. Redirección unificada: Regresa al listado manteniendo la paginación activa
header("Location: /almaceneslibertad/public/?controller=producto&action=listar&page=" . $page);
exit;
?>