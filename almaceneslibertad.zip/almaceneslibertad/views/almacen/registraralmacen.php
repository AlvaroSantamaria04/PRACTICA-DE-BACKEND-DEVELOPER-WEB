<?php
$sucursales = $sucursales ?? null;
?>
<!doctype html>
<html lang="es" style="height: 100%;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Nuevo Almacén</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #11141a !important;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .page-title { color: #e2e8f0; font-weight: 800; margin-bottom: 1.5rem; }
        .form-card {
            background: #181d26;
            border-radius: 16px;
            padding: 32px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
        }
        .section-label {
            color: #475569;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 700;
            margin-bottom: 1rem;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .form-label {
            color: #94a3b8;
            font-size: 0.82rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        .form-control, .form-select {
            background-color: #0f1218;
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
            border-radius: 8px;
            padding: 9px 13px;
            transition: all 0.2s;
        }
        .form-control:focus, .form-select:focus {
            background-color: #0f1218;
            border-color: #0d6efd;
            color: #e2e8f0;
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.18);
        }
        .form-control::placeholder { color: #3d4a5c; }
        .form-select option { background-color: #0f1218; }
        
        .form-switch .form-check-input {
            width: 2.5em;
            height: 1.3em;
            background-color: #2d3748;
            border-color: rgba(255,255,255,0.1);
            cursor: pointer;
        }
        .form-switch .form-check-input:checked {
            background-color: #198754;
            border-color: #198754;
        }
        .form-check-label { color: #94a3b8; font-size: 0.85rem; }
        .btn {
            border-radius: 8px;
            font-weight: 600;
            padding: 9px 22px;
            transition: all 0.25s;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,0.3); }
        .req { color: #f87171; margin-left: 2px; }
    </style>
</head>
<body style="min-height: 100vh; display: flex; flex-direction: column; margin: 0;">
    <?php include __DIR__ . '/../templates/menu.php'; ?>
    
    <div class="container py-4" style="flex: 1;">
        <h1 class="page-title">
            <i class="bi bi-plus-square-fill text-primary me-2"></i> Nuevo Almacén
        </h1>
        
        <div class="form-card">
            <form method="POST" action="/almaceneslibertad/public/?controller=almacen&action=registrar" novalidate>
                
                <p class="section-label"><i class="bi bi-info-circle me-1"></i> Información General del Almacén</p>
                
                <div class="row g-3 mb-4">
                    <div class="col-md-5">
                        <label class="form-label">Nombre del Almacén <span class="req">*</span></label>
                        <input type="text" name="txtNom" class="form-control" placeholder="Ej: Almacén Central Norte" maxlength="80" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Tipo de Almacén <span class="req">*</span></label>
                        <select name="cboTipo" id="cboTipo" class="form-select" required onchange="evaluarTipoAlmacen()">
                            <option value="Sucursal">Sucursal</option>
                            <option value="Central">Central</option>
                        </select>
                    </div>

                    <div class="col-md-3 d-flex flex-column justify-content-center pt-2">
                        <label class="form-label">Estado Inicial</label>
                        <div class="form-check form-switch mt-1">
                            <input class="form-check-input" type="checkbox" name="chkEst" id="chkEst" checked>
                            <label class="form-check-label" for="chkEst">Activo</label>
                        </div>
                    </div>
                </div>

                <p class="section-label"><i class="bi bi-geo-alt me-1"></i> Ubicación y Relación Cruzada</p>

                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label">Dirección <span class="req">*</span></label>
                        <input type="text" name="txtDir" class="form-control" placeholder="Ej: Av. Las Flores 456" maxlength="100" required>
                    </div>

                    <div class="col-md-6" id="contenedorSucursal">
                        <label class="form-label">Sucursal Vincular <span class="req">*</span></label>
                        <select name="cboSucursal" id="cboSucursal" class="form-select">
                            <option value="">[ Seleccione la sucursal ]</option>
                            <?php if ($sucursales): ?>
                                <?php while($suc = $sucursales->fetch_assoc()): ?>
                                    <option value="<?= $suc['codsuc']; ?>"><?= htmlspecialchars($suc['nomsuc']); ?></option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="d-flex gap-2 justify-content-end border-top border-secondary border-opacity-10 pt-3">
                    <a href="/almaceneslibertad/public/?controller=almacen&action=listar" class="btn btn-secondary px-4">
                        Cancelar
                    </a>
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="bi bi-save me-1"></i> Guardar Almacén
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php include __DIR__ . '/../templates/pie.php'; ?>

    <script>
        // Lógica interactiva premium para manejar el campo NULL en base al tipo
        function evaluarTipoAlmacen() {
            const tipo = document.getElementById('cboTipo').value;
            const cboSucursal = document.getElementById('cboSucursal');
            
            if (tipo === 'Central') {
                cboSucursal.value = "";
                cboSucursal.disabled = true;
                cboSucursal.removeAttribute('required');
            } else {
                cboSucursal.disabled = false;
                cboSucursal.setAttribute('required', 'required');
            }
        }
        
        // Listener dinámico para el switch de estado
        document.getElementById('chkEst').addEventListener('change', function() {
            this.nextElementSibling.innerText = this.checked ? 'Activo' : 'Inactivo';
        });
    </script>
</body>
</html>

                                        