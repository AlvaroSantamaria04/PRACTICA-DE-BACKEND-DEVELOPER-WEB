<?php
// Vista obsoleta y breve. El controller redirige a listar. (Funcional)
header('Location: /almaceneslibertad/public/?controller=producto&action=listar');
exit;
?>