<?php
$producto   = $producto   ?? [];
$categorias = $categorias ?? null;
$marcas     = $marcas     ?? null;
?>
<!doctype html>
<html lang="es" style="height: 100%;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Editar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #11141a !important; font-family: 'Segoe UI', system-ui, sans-serif; }
        .page-title { color: #e2e8f0; font-weight: 800; margin-bottom: 1.5rem; }
        .form-card {
            background: #181d26;
            border-radius: 16px;
            padding: 32px;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 12px 40px rgba(0,0,0,0.5);
        }
        .id-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(13,110,253,0.12);
            border: 1px solid rgba(13,110,253,0.25);
            color: #60a5fa;
            border-radius: 8px;
            padding: 5px 14px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
        }
        .section-label {
            color: #475569;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 700;
            margin-bottom: 1rem;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .form-label { color: #94a3b8; font-size: 0.82rem; font-weight: 600; margin-bottom: 5px; }
        .form-control, .form-select {
            background-color: #0f1218;
            border: 1px solid rgba(255,255,255,0.1);
            color: #e2e8f0;
            border-radius: 8px;
            padding: 9px 13px;
            transition: all 0.2s;
        }
        .form-control:focus, .form-select:focus {
            background-color: #0f1218;
            border-color: #0d6efd;
            color: #e2e8f0;
            box-shadow: 0 0 0 3px rgba(13,110,253,0.18);
        }
        .form-control::placeholder { color: #3d4a5c; }
        .form-select option { background-color: #0f1218; }
        .form-switch .form-check-input {
            width: 2.5em; height: 1.3em;
            background-color: #2d3748;
            border-color: rgba(255,255,255,0.1);
            cursor: pointer;
        }
        .form-switch .form-check-input:checked { background-color: #198754; border-color: #198754; }
        .form-check-label { color: #94a3b8; font-size: 0.85rem; }
        .btn { border-radius: 8px; font-weight: 600; padding: 9px 22px; transition: all 0.25s; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,0.3); }
        .req { color: #f87171; margin-left: 2px; }
    </style>
</head>
<body style="min-height: 100vh; display: flex; flex-direction: column; margin: 0;">

    <?php include __DIR__ . '/../templates/menu.php'; ?>

    <div class="container py-4" style="flex: 1;">

        <h1 class="page-title">
            <i class="bi bi-pencil-square text-warning me-2"></i> Editar Producto
        </h1>

        <div class="id-badge">
            <i class="bi bi-hash"></i>
            Editando ID: <?= htmlspecialchars((string)($producto['codpro'] ?? '—')); ?>
            &nbsp;|&nbsp;
            <span style="color:#94a3b8;">
                <?= htmlspecialchars((string)($producto['nompro'] ?? 'Sin datos')); ?>
            </span>
        </div>

        <div class="form-card">
            <form method="POST"
                  action="/almaceneslibertad/public/?controller=producto&action=actualizar"
                  novalidate>

                <input type="hidden" name="txtCod" value="<?= (int)($producto['codpro'] ?? 0); ?>">

                <!-- INFORMACIÓN GENERAL -->
                <p class="section-label"><i class="bi bi-info-circle me-1"></i> Información general</p>
                <div class="row g-3">

                    <div class="col-md-8">
                        <label class="form-label">Nombre del Producto <span class="req">*</span></label>
                        <input type="text"
                               name="txtNom"
                               class="form-control"
                               value="<?= htmlspecialchars((string)($producto['nompro'] ?? '')); ?>"
                               maxlength="80"
                               required>
                    </div>

                    <div class="col-md-4 d-flex flex-column justify-content-center">
                        <label class="form-label">Estado</label>
                        <div class="form-check form-switch mt-1">
                            <?php
                                
                                $activo = isset($producto['estpro']) && ord((string)$producto['estpro']) === 1;
                            ?>
                            <input class="form-check-input"
                                   type="checkbox"
                                   name="chkEst"
                                   id="chkEst"
                                   <?= $activo ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="chkEst">Activo</label>
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Descripción <span class="req">*</span></label>
                        <textarea name="txtDes"
                                  class="form-control"
                                  rows="3"
                                  maxlength="300"
                                  required><?= htmlspecialchars((string)($producto['despre'] ?? '')); ?></textarea>
                    </div>

                </div>

                <!-- CLASIFICACIÓN -->
                <p class="section-label mt-4"><i class="bi bi-diagram-3 me-1"></i> Clasificación</p>
                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">Categoría <span class="req">*</span></label>
                        <select name="selCat" class="form-select" required>
                            <option value="">-- Seleccione una categoría --</option>
                            <?php
                            $catActual = (int)($producto['codcat'] ?? 0);
                            if ($categorias && $categorias->num_rows > 0):
                                while ($cat = $categorias->fetch_assoc()): ?>
                                <option value="<?= (int)$cat['codcat']; ?>"
                                    <?= (int)$cat['codcat'] === $catActual ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($cat['nomcat']); ?>
                                </option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Marca <span class="req">*</span></label>
                        <select name="selMar" class="form-select" required>
                            <option value="">-- Seleccione una marca --</option>
                            <?php
                            $marActual = (int)($producto['codmar'] ?? 0);
                            if ($marcas && $marcas->num_rows > 0):
                                while ($mar = $marcas->fetch_assoc()): ?>
                                <option value="<?= (int)$mar['codmar']; ?>"
                                    <?= (int)$mar['codmar'] === $marActual ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($mar['nommar']); ?>
                                </option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>

                </div>

                <!-- PRECIO Y STOCK -->
                <p class="section-label mt-4"><i class="bi bi-currency-exchange me-1"></i> Precio y Stock</p>
                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">Precio (S/) <span class="req">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"
                                  style="background:#0f1218; border-color:rgba(255,255,255,0.1); color:#64748b;">
                                S/
                            </span>
                            <input type="number"
                                   name="txtPre"
                                   class="form-control"
                                   value="<?= number_format((float)($producto['prepro'] ?? 0), 2, '.', ''); ?>"
                                   step="0.01"
                                   min="0.01"
                                   required>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Stock <span class="req">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"
                                  style="background:#0f1218; border-color:rgba(255,255,255,0.1); color:#64748b;">
                                <i class="bi bi-boxes"></i>
                            </span>
                            <input type="number"
                                   name="txtCan"
                                   class="form-control"
                                   value="<?= (int)($producto['canpro'] ?? 0); ?>"
                                   min="0"
                                   required>
                        </div>
                    </div>

                </div>

                <!-- BOTONES -->
                <div class="d-flex gap-2 mt-4 pt-2 border-top"
                     style="border-color: rgba(255,255,255,0.06) !important;">
                    <button type="submit" class="btn btn-warning px-4 text-dark">
                        <i class="bi bi-floppy-fill me-1"></i> Guardar Cambios
                    </button>
                    <a href="/almaceneslibertad/public/?controller=producto&action=listar"
                       class="btn btn-secondary px-4">
                        <i class="bi bi-x-lg me-1"></i> Cancelar
                    </a>
                </div>

            </form>
        </div>

    </div>

    <?php include __DIR__ . '/../templates/pie.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>