<?php
// Vista: deshabilitarproducto.php
?>