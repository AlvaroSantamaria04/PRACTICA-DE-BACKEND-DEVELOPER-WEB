<?php
$productos    = $productos    ?? null;
$totalPaginas = $totalPaginas ?? 0;
$pagina       = $pagina       ?? 1;
$limite       = $limite       ?? 10;
?>
<!doctype html>
<html lang="es" style="height: 100%;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #11141a !important;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        .page-title {
            color: #e2e8f0;
            font-weight: 800;
            margin-bottom: 1.5rem;
        }

        .table-container {
            background: #181d26;
            border-radius: 16px;
            padding: 24px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
        }

        /* CABECERA OSCURA */
        .table thead tr {
            background-color: #212529;
        }
        .table thead th {
            color: #9fadc0;
            font-size: 0.76rem;
            text-transform: uppercase;
            letter-spacing: 0.07em;
            border-bottom: 2px solid rgba(255, 255, 255, 0.08) !important;
            border-top: none !important;
            padding: 13px 12px;
            white-space: nowrap;
        }

        /* CUERPO BLANCO */
        .table tbody {
            background-color: #ffffff;
        }
        .table tbody td {
            border-color: #e9ecef;
            padding: 9px 12px;
            vertical-align: middle;
        }
        .table tbody tr:hover td {
            background-color: #f0f7ff;
        }

        /* DESCRIPCIÓN truncada */
        .desc-cell {
            max-width: 170px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            color: #6c757d;
            font-size: 0.85rem;
        }

        /* BOTONES */
        .btn {
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.25s ease;
            font-size: 0.8rem;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.25);
        }
        .btn-actualizar {
            background-color: #198754;
            color: #fff;
            border: none;
            padding: 5px 12px;
        }
        .btn-actualizar:hover { background-color: #157347; color: #fff; }
        .btn-deshabilitar {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 5px 12px;
        }
        .btn-deshabilitar:hover { background-color: #bb2d3b; color: #fff; }
        .btn-habilitar {
            background-color: #0d6efd;
            color: #fff;
            border: none;
            padding: 5px 12px;
        }
        .btn-habilitar:hover { background-color: #0b5ed7; color: #fff; }

        /* PAGINACIÓN OSCURA */
        .pagination { gap: 4px; }
        .pagination .page-link {
            background-color: #1e2330;
            border: 1px solid rgba(255, 255, 255, 0.09);
            color: #8a98b0 !important;
            border-radius: 8px !important;
            padding: 7px 14px;
            font-weight: 500;
            transition: all 0.2s;
        }
        .pagination .page-link:hover {
            background-color: #0d6efd;
            color: #fff !important;
            border-color: #0d6efd;
        }
        .pagination .page-item.active .page-link {
            background-color: #0d6efd !important;
            border-color: #0d6efd !important;
            color: #fff !important;
        }
        .pagination .page-item.disabled .page-link {
            background-color: #13161e;
            color: #3d4a5c !important;
            border-color: rgba(255, 255, 255, 0.04);
        }

        /* INFO CARD SUPERIOR */
        .info-bar {
            color: #64748b;
            font-size: 0.85rem;
            margin-bottom: 1rem;
        }
        .info-bar strong { color: #94a3b8; }
    </style>
</head>

<body style="min-height: 100vh; display: flex; flex-direction: column; margin: 0;">

    <?php include __DIR__ . '/../templates/menu.php'; ?>

    <div class="container-fluid px-4 mt-4" style="flex: 1;">

        <h1 class="page-title">
            <i class="bi bi-box-seam-fill text-primary me-2"></i> Listado de Productos
        </h1>

        <!-- BOTONES SUPERIORES -->
        <div class="mb-3 d-flex gap-2 flex-wrap">
            <a href="/almaceneslibertad/public/?controller=producto&action=registro"
               class="btn btn-primary px-4">
                <i class="bi bi-plus-lg me-1"></i> Nuevo Producto
            </a>
            <a href="/almaceneslibertad/public/?controller=inicio&action=menu"
               class="btn btn-secondary px-4">
                <i class="bi bi-arrow-left-short me-1"></i> Regresar
            </a>
        </div>

        <!-- BARRA DE INFORMACIÓN -->
        <p class="info-bar">
            Página <strong><?= $pagina; ?></strong> de <strong><?= max($totalPaginas, 1); ?></strong>
            &nbsp;|&nbsp; Registros del
            <strong><?= ($pagina - 1) * $limite + 1; ?></strong> al
            <strong><?= min($pagina * $limite, ($totalPaginas * $limite)); ?></strong>
        </p>

        <!-- TABLA -->
        <div class="table-responsive table-container">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width:42px;">N°</th>
                        <th style="width:50px;">Cód.</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Categoría</th>
                        <th>Marca</th>
                        <th class="text-end">Precio (S/)</th>
                        <th class="text-center">Stock</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center" style="width:100px;">Actualizar</th>
                        <th class="text-center" style="width:125px;">Habilitar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($productos && $productos->num_rows > 0):
                        $cont = ($pagina - 1) * $limite + 1;
                    ?>
                        <?php while ($fila = $productos->fetch_assoc()): ?>
                            <tr>
                                <!-- N° CORRELATIVO -->
                                <td>
                                    <span class="badge bg-secondary fw-normal"><?= $cont++; ?></span>
                                </td>

                                <!-- CÓDIGO BD -->
                                <td>
                                    <small class="text-muted"><?= $fila['codpro']; ?></small>
                                </td>

                                <!-- NOMBRE -->
                                <td class="fw-semibold text-dark">
                                    <?= htmlspecialchars($fila['nompro']); ?>
                                </td>

                                <!-- DESCRIPCIÓN TRUNCADA (tooltip al hover) -->
                                <td title="<?= htmlspecialchars($fila['despre']); ?>">
                                    <div class="desc-cell"><?= htmlspecialchars($fila['despre']); ?></div>
                                </td>

                                <!-- CATEGORÍA (DATO CRUZADO) -->
                                <td>
                                    <span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1">
                                        <i class="bi bi-tag-fill me-1"></i><?= htmlspecialchars($fila['nomcat']); ?>
                                    </span>
                                </td>

                                <!-- MARCA (DATO CRUZADO) -->
                                <td>
                                    <span class="badge bg-info bg-opacity-10 text-info px-2 py-1">
                                        <i class="bi bi-award-fill me-1"></i><?= htmlspecialchars($fila['nommar']); ?>
                                    </span>
                                </td>

                                <!-- PRECIO -->
                                <td class="text-end fw-bold text-dark">
                                    <?= number_format((float)$fila['prepro'], 2); ?>
                                </td>

                                <!-- STOCK (badge rojo si es 0) -->
                                <td class="text-center">
                                    <span class="badge <?= (int)$fila['canpro'] > 0 ? 'bg-success' : 'bg-danger'; ?>">
                                        <?= $fila['canpro']; ?>
                                    </span>
                                </td>

                                <!-- ESTADO BADGE -->
                                <td class="text-center">
                                    <?php if ($fila['estpro'] == 1): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">
                                            <i class="bi bi-check-circle-fill me-1"></i>Activo
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                            <i class="bi bi-x-circle-fill me-1"></i>Inactivo
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- BTN ACTUALIZAR (Verde #198754) -->
                                <td class="text-center">
                                    <a href="/almaceneslibertad/public/?controller=producto&action=actualiza&id=<?= $fila['codpro']; ?>&page=<?= $pagina; ?>"
                                       class="btn btn-actualizar">
                                        <i class="bi bi-pencil-square me-1"></i>Editar
                                    </a>
                                </td>

                                <!-- BTN ESTADO CONDICIONAL (Rojo deshabilitar / Azul habilitar) -->
                                <td class="text-center">
                                    <?php if ($fila['estpro'] == 1): ?>
                                        <a href="/almaceneslibertad/public/?controller=producto&action=deshabilitar&id=<?= $fila['codpro']; ?>&page=<?= $pagina; ?>"
                                           class="btn btn-deshabilitar"
                                           onclick="return confirm('¿Deshabilitar el producto:\n«<?= htmlspecialchars(addslashes($fila['nompro'])); ?>»?')">
                                            <i class="bi bi-toggle-on me-1"></i>Deshabilitar
                                        </a>
                                    <?php else: ?>
                                        <a href="/almaceneslibertad/public/?controller=producto&action=habilitar&id=<?= $fila['codpro']; ?>&page=<?= $pagina; ?>"
                                           class="btn btn-habilitar"
                                           onclick="return confirm('¿Habilitar el producto:\n«<?= htmlspecialchars(addslashes($fila['nompro'])); ?>»?')">
                                            <i class="bi bi-toggle-off me-1"></i>Habilitar
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="11" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <span class="text-muted">No existen productos registrados</span>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div><!-- /table-container -->

        <!-- PAGINACIÓN OSCURA -->
        <?php if ($totalPaginas > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= ($pagina <= 1) ? 'disabled' : ''; ?>">
                        <a class="page-link"
                           href="?controller=producto&action=listar&page=<?= $pagina - 1; ?>">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <li class="page-item <?= ($i == $pagina) ? 'active' : ''; ?>">
                            <a class="page-link"
                               href="?controller=producto&action=listar&page=<?= $i; ?>"><?= $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($pagina >= $totalPaginas) ? 'disabled' : ''; ?>">
                        <a class="page-link"
                           href="?controller=producto&action=listar&page=<?= $pagina + 1; ?>">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div><!-- /container -->

    <?php include __DIR__ . '/../templates/pie.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>