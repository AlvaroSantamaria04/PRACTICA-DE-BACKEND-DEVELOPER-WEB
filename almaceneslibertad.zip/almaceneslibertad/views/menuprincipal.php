<?php 
$include_path = 'templates/menu.php'; 
include $include_path; 
?>

<!doctype html>
<html lang="es" style="height: 100%;">
<body style="min-height: 100vh; display: flex; flex-direction: column; margin: 0; background-color: #ffffff; color: #333333; font-family: system-ui, sans-serif;">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <div class="container mt-5" style="flex: 1;">
        
        <div class="p-5 mb-4 rounded-4 shadow-lg" style="background: linear-gradient(135deg, #0d6efd 0%, #004494 100%); color: #ffffff; border: none;">
            <div class="container-fluid py-3">
                <h1 class="display-4 fw-bold">
                    <i class="bi bi-speedometer2 me-3"></i>Bienvenido al Sistema de Gestión
                </h1>
                <p class="col-md-10 fs-4 mt-4" style="opacity: 0.9;">
                    Has ingresado al panel de control de <strong>Almacenes libertad</strong>. 
                    Desde la barra superior puedes acceder de manera rápida y estructurada al diseño de base de datos, mantenimientos de tablas y exportación de reportes PDF.
                </p>
                <div class="mt-4">
                    <span class="badge bg-light text-primary fs-6 p-2 px-3">
                        <i class="bi bi-check-circle-fill me-2"></i>Sistema Activo
                    </span>
                </div>
            </div>
        </div>

    </div>

    <?php 
    $pie_path = 'templates/pie.php'; 
    include $pie_path; 
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>