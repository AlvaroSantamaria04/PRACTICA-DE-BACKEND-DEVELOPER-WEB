<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Ingreso al Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    
    <style>
        /* Fondo animado y futurista con gradiente de alta energía */
        body {
            background: linear-gradient(-45deg, #7431F9, #0ea5e9, #4b0082, #1e1b4b);
            background-size: 400% 400%;
            animation: gradientBg 15s ease infinite;
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, sans-serif;
            overflow-x: hidden;
        }

        @keyframes gradientBg {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Tarjeta con efecto Glassmorphism (Vidrio translúcido) */
        .card {
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 24px !important;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        }

        /* Encabezado con texto brillante */
        .card-header {
            background: transparent;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            padding: 2rem 1rem;
        }

        .card-header h1 {
            color: #ffffff;
            font-size: 1.75rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.5), 0 0 20px rgba(116, 49, 249, 0.5);
        }

        .card-body {
            padding: 2.5rem;
        }

        /* Etiquetas en color blanco brillante */
        .form-label {
            color: #ffffff;
            font-weight: 600;
            font-size: 0.9rem;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        /* Inputs estilizados semi-transparentes */
        .form-control {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            color: #ffffff !important;
            padding: 0.8rem 1.2rem;
            transition: all 0.3s ease;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        /* Enfoque de inputs con destello de neón */
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: #0ea5e9;
            box-shadow: 0 0 15px rgba(14, 165, 233, 0.6);
            outline: 0;
        }

        /* Botón de ingreso con gradiente llamativo y efecto de elevación */
        .btn-ingresar {
            background: linear-gradient(135deg, #0ea5e9 0%, #7431F9 100%);
            border: none;
            color: white;
            padding: 0.85rem;
            font-weight: 700;
            font-size: 1.05rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(116, 49, 249, 0.4);
            transition: all 0.3s ease;
        }

        .btn-ingresar:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(14, 165, 233, 0.6);
            opacity: 0.95;
        }

        .btn-ingresar:active {
            transform: translateY(-1px);
        }

        /* Alerta de error estilizada para que encaje con el diseño */
        .alert-danger {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #fca5a5;
            backdrop-filter: blur(5px);
            border-radius: 12px;
        }

        /* Pie de página sutil y limpio */
        .card-footer {
            background: rgba(0, 0, 0, 0.15);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.85rem;
            padding: 1.25rem;
            border-bottom-left-radius: 24px !important;
            border-bottom-right-radius: 24px !important;
        }
        
        .card-footer strong {
            color: #0ea5e9;
        }
    </style>
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">

        <div class="card shadow-lg" style="max-width: 420px; width: 100%;">

            <div class="card-header text-center">
                <h1>Ingreso al Sistema</h1>
            </div>

            <div class="card-body">

                <?php if (!empty($mensaje)): ?>
                    <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
                        <?= $mensaje ?>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>

                <form method="post" action="/almaceneslibertad/public/?controller=empleado&action=login">

                    <div class="mb-4">
                        <label for="txtUsu" class="form-label">Usuario</label>
                        <input type="text" class="form-control" id="txtUsu" name="txtUsu"
                            placeholder="Ingresa tu usuario" required autocomplete="username">
                    </div>

                    <div class="mb-4">
                        <label for="txtCla" class="form-label">Clave</label>
                        <input type="password" class="form-control" id="txtCla" name="txtCla"
                            placeholder="Ingresa tu clave" required autocomplete="current-password">
                    </div>

                    <div class="d-grid gap-2 pt-2">
                        <button type="submit" class="btn btn-ingresar">Ingresar</button>
                    </div>

                </form>
                </div>

            <div class="card-footer text-center">
                Desarrollado por <strong>AlmacenLibertad</strong>
            </div>

        </div>
        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>

</body>

</html>