<footer class="text-white text-center py-3 mt-auto" style="background: #0a0c10; border-top: 1px solid rgba(255,255,255,0.05);">
    <div class="container">
        <p class="mb-0" style="font-size: 0.88rem; color: #a0a5b0;">
            &copy; <?= date('Y'); ?> - <span class="text-white fw-bold">Almacenes libertad</span> | Todos los derechos reservados.
        </p>
    </div>
</footer>