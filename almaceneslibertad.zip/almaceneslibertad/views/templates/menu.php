<?php
if (session_status() === PHP_SESSION_NONE) {
}
?>

<style>
    .navbar-custom {
        background: linear-gradient(135deg, #161920 0%, #0e1116 100%) !important;
        padding: 0.75rem 2rem;
        border-bottom: 2px solid rgba(13, 110, 253, 0.2);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }

    .navbar-custom .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 1.3rem;
        text-transform: uppercase;
        background: linear-gradient(45deg, #ffffff, #0d6efd);
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .navbar-custom .nav-link {
        color: #9fa6b2 !important;
        font-weight: 500;
        padding: 0.6rem 1rem !important;
        margin: 0 0.2rem;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    .navbar-custom .nav-link:hover {
        color: #ffffff !important;
        background-color: rgba(13, 110, 253, 0.15);
    }

    
    .dropdown-menu-clear-custom {
        background: #ffffff !important; /* Fondo blanco iluminado */
        border: 1px solid rgba(0, 0, 0, 0.08) !important;
        border-radius: 12px !important;
        padding: 0.6rem !important;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15) !important;
        min-width: 220px;
    }

    .dropdown-menu-clear-custom .dropdown-item {
        color: #212529 !important; /* Texto gris oscuro de alta legibilidad */
        font-weight: 500 !important;
        padding: 0.6rem 1.2rem !important;
        border-radius: 8px !important;
        transition: all 0.2s ease !important;
        display: flex;
        align-items: center;
    }

    /* Efecto Hover: Resaltado azul con texto e icono blanco */
    .dropdown-menu-clear-custom .dropdown-item:hover {
        background: #0d6efd !important;
        color: #ffffff !important;
    }

    /* Fuerza a los iconos mutados a cambiar a blanco en hover */
    .dropdown-menu-clear-custom .dropdown-item:hover i {
        color: #ffffff !important;
    }

    /* Separadores internos más limpios */
    .dropdown-menu-clear-custom .dropdown-divider {
        border-top: 1px solid rgba(0, 0, 0, 0.08) !important;
        margin: 0.5rem 0;
    }

    /* Texto informativo del usuario logueado en la sección Cuenta */
    .dropdown-menu-clear-custom .user-info-text {
        color: #5c636a !important;
        font-weight: 600 !important;
        padding: 0.6rem 1.2rem !important;
        display: flex;
        align-items: center;
        font-size: 0.9rem;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container-fluid">
        <a class="navbar-brand" href="/almaceneslibertad/public/">
            <i class="bi bi-box-seam-fill me-2 text-primary"></i>Almacenes libertad
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <li class="nav-item">
                    <a class="nav-link" href="/almaceneslibertad/public/">
                        <i class="bi bi-house-door me-2"></i>Inicio
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="bi bi-info-circle me-2"></i>Quienes Somos
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-file-earmark-diff me-2 text-primary"></i>M. Simple
                    </a>
                    <ul class="dropdown-menu dropdown-menu-clear-custom">
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=categoria&action=listar">
                                <i class="bi bi-tag-fill me-2 text-muted"></i>Categoría
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=distrito&action=listar">
                                <i class="bi bi-geo-alt-fill me-2 text-muted"></i>Distrito
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=marca&action=listar">
                                <i class="bi bi-bookmark-star-fill me-2 text-muted"></i>Marca
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=rol&action=listar">
                                <i class="bi bi-shield-lock-fill me-2 text-muted"></i>Rol
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=sexo&action=listar">
                                <i class="bi bi-gender-ambiguous me-2 text-muted"></i>Sexo
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=tipodocumento&action=listar">
                                <i class="bi bi-card-text me-2 text-muted"></i>Tipo Documento
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-diagram-3-fill me-2 text-success"></i>M. Cruzado
                    </a>
                    <ul class="dropdown-menu dropdown-menu-clear-custom">
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=almacen&action=listar">
                                <i class="bi bi-building me-2 text-muted"></i>Almacén
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=empleado&action=listar">
                                <i class="bi bi-people me-2 text-muted"></i>Empleado
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=inventarioalmacen&action=listar">
                                <i class="bi bi-boxes me-2 text-muted"></i>Inventario Almacén
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=producto&action=listar">
                                <i class="bi bi-cart-fill me-2 text-muted"></i>Producto
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=proveedor&action=listar">
                                <i class="bi bi-truck me-2 text-muted"></i>Proveedor
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=sucursal&action=listar">
                                <i class="bi bi-shop me-2 text-muted"></i>Sucursal
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-layout-three-columns me-2 text-warning"></i>M.Detalle
                    </a>
                    <ul class="dropdown-menu dropdown-menu-clear-custom">
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=detalleentrada&action=listar">
                                <i class="bi bi-file-earmark-text-fill me-2 text-muted"></i>Detalle Entrada
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=detallesalida&action=listar">
                                <i class="bi bi-file-earmark-text-fill me-2 text-muted"></i>Detalle Salida
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=detalletraslado&action=listar">
                                <i class="bi bi-file-earmark-text-fill me-2 text-muted"></i>Detalle Traslado
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=registroentrada&action=listar">
                                <i class="bi bi-clipboard-check-fill me-2 text-muted"></i>Registro Entrada
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=registrosalida&action=listar">
                                <i class="bi bi-clipboard-minus-fill me-2 text-muted"></i>Registro Salida
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/almaceneslibertad/public/?controller=traslado&action=listar">
                                <i class="bi bi-arrow-left-right me-2 text-muted"></i>Traslado
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-file-earmark-pdf me-2 text-danger"></i>Reportes (PDF)
                    </a>
                    <ul class="dropdown-menu dropdown-menu-clear-custom">
                        <li>
                            <a class="dropdown-item" href="#">
                                <i class="bi bi-file-earmark-arrow-down-fill me-2 text-muted"></i>Reporte de Entrada
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#">
                                <i class="bi bi-file-earmark-arrow-up-fill me-2 text-muted"></i>Reporte de Salida
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-2"></i>Cuenta
                    </a>
                    <ul class="dropdown-menu dropdown-menu-clear-custom dropdown-menu-end">
                        <?php if (isset($_SESSION['empleado'])): ?>
                            <li>
                                <span class="user-info-text">
                                    <i class="bi bi-person-badge-fill me-2 text-primary"></i>
                                    <?= htmlspecialchars($_SESSION['empleado']['nomemp'] . ' ' . $_SESSION['empleado']['apepemp']); ?>
                                </span>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="/almaceneslibertad/public/?controller=empleado&action=logout">
                                    <i class="bi bi-power me-2"></i>Cerrar Sesión
                                </a>
                            </li>
                        <?php else: ?>
                            <li>
                                <a class="dropdown-item" href="/almaceneslibertad/public/?controller=empleado&action=login">
                                    <i class="bi bi-box-arrow-in-right me-2 text-success"></i>Iniciar Sesión
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>