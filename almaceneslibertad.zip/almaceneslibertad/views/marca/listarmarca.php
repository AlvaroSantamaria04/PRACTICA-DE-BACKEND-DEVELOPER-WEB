<?php
$marcas       = $marcas       ?? null;
$totalPaginas = $totalPaginas ?? 0;
$pagina       = $pagina       ?? 1;
?>
<!doctype html>
<html lang="es" style="height: 100%;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Almacenes Libertad | Lista Marca</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f4f8 !important; font-family: 'Segoe UI', system-ui, sans-serif; }
        .table-container { background: #ffffff; border-radius: 16px; padding: 25px; border: 1px solid #d1d9e6; box-shadow: 0 10px 30px rgba(0,50,100,0.1); }
        h1 { color: #1e293b; font-weight: 800; margin-bottom: 1.5rem; }
        .table thead { background-color: #f1f5f9; color: #475569; }
        .btn { border-radius: 8px; font-weight: 500; transition: all 0.3s; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .pagination { gap: 5px; }
        .pagination .page-link { color: #000 !important; background-color: #fff; border: 1px solid #dee2e6; border-radius: 4px !important; padding: 8px 16px; font-weight: 500; }
        .pagination .page-item.active .page-link { background-color: #000 !important; border-color: #000 !important; color: #fff !important; }
        .pagination .page-item:first-child .page-link,
        .pagination .page-item:last-child .page-link { background-color: #000; color: #fff !important; border-color: #000; }
    </style>
</head>
<body style="min-height: 100vh; display: flex; flex-direction: column; margin: 0;">
    <?php include __DIR__ . '/../templates/menu.php'; ?>

    <div class="container mt-5" style="flex: 1;">
        <h1><i class="bi bi-award-fill text-primary"></i> Listado de Marcas</h1>

        <div class="mb-4">
            <a href="/almaceneslibertad/public/?controller=marca&action=registro" class="btn btn-primary px-4"><i class="bi bi-plus-lg"></i> Nueva Marca</a>
            <a href="/almaceneslibertad/public/?controller=marca&action=habilita" class="btn btn-warning px-4"><i class="bi bi-check2-circle"></i> Habilitar</a>
            <a href="/almaceneslibertad/public/?controller=marca&action=menu" class="btn btn-secondary px-4">Regresar</a>
        </div>

        <div class="table-responsive table-container">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th class="text-center">Actualizar</th>
                        <th class="text-center">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($marcas && $marcas->num_rows > 0): ?>
                        <?php while ($fila = $marcas->fetch_assoc()): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?= $fila['codmar']; ?></span></td>
                                <td class="fw-bold"><?= htmlspecialchars($fila['nommar']); ?></td>
                                <td>
                                    <?php if ($fila['estmar'] == 1): ?>
                                        <span class="badge bg-success-subtle text-success">Habilitado</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">Deshabilitado</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="/almaceneslibertad/public/?controller=marca&action=actualiza&id=<?= $fila['codmar']; ?>&page=<?= $pagina; ?>" class="btn btn-success btn-sm">
                                        <i class="bi bi-pencil-square me-1"></i> Actualizar
                                    </a>
                                </td>
                                <td class="text-center">
                                    <a href="/almaceneslibertad/public/?controller=marca&action=eliminar&id=<?= $fila['codmar']; ?>&page=<?= $pagina; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Deseas eliminar esta marca?')">
                                        <i class="bi bi-trash-fill me-1"></i> Eliminar
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-4 text-muted">No existen registros</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPaginas > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= ($pagina <= 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?controller=marca&action=listar&page=<?= $pagina - 1; ?>">Anterior</a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <li class="page-item <?= ($i == $pagina) ? 'active' : ''; ?>">
                            <a class="page-link" href="?controller=marca&action=listar&page=<?= $i; ?>"><?= $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($pagina >= $totalPaginas) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?controller=marca&action=listar&page=<?= $pagina + 1; ?>">Siguiente</a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    </div>

    <?php include __DIR__ . '/../templates/pie.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>