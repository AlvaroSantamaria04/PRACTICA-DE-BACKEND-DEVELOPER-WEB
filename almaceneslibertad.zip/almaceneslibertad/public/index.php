<?php
    session_start(); 
    require_once '../routes/rutas.php';
?>