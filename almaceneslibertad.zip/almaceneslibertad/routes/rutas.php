<?php
// ────────────────────────────────────────────────────────────────────────────
// Router principal — almaceneslibertad
// Patrón: ?controller=<entidad>&action=<accion>[&id=<n>&page=<n>]
// ────────────────────────────────────────────────────────────────────────────

$controller = isset($_GET['controller']) ? strtolower(trim($_GET['controller'])) : 'inicio';
$action     = isset($_GET['action'])     ? strtolower(trim($_GET['action']))     : 'menu';

switch ($controller) {

    // ── INICIO ────────────────────────────────────────────────────────────
    case 'inicio':
        require_once __DIR__ . '/../controllers/InicioController.php';
        $obj = new InicioController();
        switch ($action) {
            case 'menu': $obj->MenuPrincipal(); break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── SEXO ──────────────────────────────────────────────────────────────
    case 'sexo':
        require_once __DIR__ . '/../controllers/SexoController.php';
        $obj = new SexoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── CATEGORIA ─────────────────────────────────────────────────────────
    case 'categoria':
        require_once __DIR__ . '/../controllers/CategoriaController.php';
        $obj = new CategoriaController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── MARCA ─────────────────────────────────────────────────────────────
    case 'marca':
        require_once __DIR__ . '/../controllers/MarcaController.php';
        $obj = new MarcaController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── DISTRITO ──────────────────────────────────────────────────────────
    case 'distrito':
        require_once __DIR__ . '/../controllers/DistritoController.php';
        $obj = new DistritoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── ROL ───────────────────────────────────────────────────────────────
    case 'rol':
        require_once __DIR__ . '/../controllers/RolController.php';
        $obj = new RolController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── TIPODOCUMENTO ─────────────────────────────────────────────────────
    case 'tipodocumento':
        require_once __DIR__ . '/../controllers/TipoDocumentoController.php';
        $obj = new TipoDocumentoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── SUCURSAL ──────────────────────────────────────────────────────────
    case 'sucursal':
        require_once __DIR__ . '/../controllers/SucursalController.php';
        $obj = new SucursalController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── ALMACEN ───────────────────────────────────────────────────────────
    case 'almacen':
        require_once __DIR__ . '/../controllers/AlmacenController.php';
        $obj = new AlmacenController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── EMPLEADO ──────────────────────────────────────────────────────────
    case 'empleado':
        require_once __DIR__ . '/../controllers/EmpleadoController.php';
        $obj = new EmpleadoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'login':        $obj->login();        break;
            case 'logout':       $obj->logout();       break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── PROVEEDOR ─────────────────────────────────────────────────────────
    case 'proveedor':
        require_once __DIR__ . '/../controllers/ProveedorController.php';
        $obj = new ProveedorController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── PRODUCTO ──────────────────────────────────────────────────────────
    case 'producto':
        require_once __DIR__ . '/../controllers/ProductoController.php';
        $obj = new ProductoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── INVENTARIO ALMACEN ────────────────────────────────────────────────
    case 'inventarioalmacen':
        require_once __DIR__ . '/../controllers/InventarioAlmacenController.php';
        $obj = new InventarioAlmacenController();
        switch ($action) {
            case 'listar':     $obj->listar();     break;
            case 'registro':   $obj->registro();   break;
            case 'registrar':  $obj->registrar();  break;
            case 'actualiza':  $obj->actualiza();  break;
            case 'actualizar': $obj->actualizar(); break;
            case 'eliminar':   $obj->eliminar();   break;
            case 'menu':       $obj->menu();       break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── REGISTRO ENTRADA ──────────────────────────────────────────────────
    case 'registroentrada':
        require_once __DIR__ . '/../controllers/RegistroEntradaController.php';
        $obj = new RegistroEntradaController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── DETALLE ENTRADA (AJAX) ────────────────────────────────────────────
    case 'detalleentrada':
        require_once __DIR__ . '/../controllers/DetalleEntradaController.php';
        $obj = new DetalleEntradaController();
        switch ($action) {
            case 'listar':    $obj->listar();    break;  // GET: devuelve JSON por nroent
            case 'registrar': $obj->registrar(); break;  // POST: añade línea + actualiza stock
            case 'eliminar':  $obj->eliminar();  break;  // GET: elimina línea por id
            case 'menu':      $obj->menu();      break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── REGISTRO SALIDA ───────────────────────────────────────────────────
    case 'registrosalida':
        require_once __DIR__ . '/../controllers/RegistroSalidaController.php';
        $obj = new RegistroSalidaController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── DETALLE SALIDA (AJAX) ─────────────────────────────────────────────
    case 'detalleSalida':
    case 'detallesalida':
        require_once __DIR__ . '/../controllers/DetalleSalidaController.php';
        $obj = new DetalleSalidaController();
        switch ($action) {
            case 'listar':    $obj->listar();    break;  // GET: devuelve JSON por nrosal
            case 'registrar': $obj->registrar(); break;  // POST: añade línea + descuenta stock
            case 'eliminar':  $obj->eliminar();  break;  // GET: elimina línea por id
            case 'menu':      $obj->menu();      break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── TRASLADO ──────────────────────────────────────────────────────────
    case 'traslado':
        require_once __DIR__ . '/../controllers/TrasladoController.php';
        $obj = new TrasladoController();
        switch ($action) {
            case 'listar':       $obj->listar();       break;
            case 'registro':     $obj->registro();     break;
            case 'registrar':    $obj->registrar();    break;
            case 'actualiza':    $obj->actualiza();    break;
            case 'actualizar':   $obj->actualizar();   break;
            case 'eliminar':     $obj->eliminar();     break;
            case 'habilita':     $obj->habilita();     break;
            case 'habilitar':    $obj->habilitar();    break;
            case 'deshabilitar': $obj->deshabilitar(); break;
            case 'menu':         $obj->menu();         break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── DETALLE TRASLADO (AJAX) ───────────────────────────────────────────
    case 'detalletraslado':
        require_once __DIR__ . '/../controllers/DetalleTrasladoController.php';
        $obj = new DetalleTrasladoController();
        switch ($action) {
            case 'listar':    $obj->listar();    break;  // GET: devuelve JSON por codtra
            case 'registrar': $obj->registrar(); break;  // POST: añade línea + mueve stock
            case 'eliminar':  $obj->eliminar();  break;  // GET: elimina línea por id
            case 'menu':      $obj->menu();      break;
            default: echo "Acción no encontrada"; break;
        }
    break;

    // ── DEFAULT ───────────────────────────────────────────────────────────
    default:
        echo "Controlador '$controller' no encontrado.";
    break;
}
?>
