<?php
require_once '../models/Categoria.php';
$modelo = new Categoria();

echo "<h2>Listado de Categorías Habilitadas</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codcat'] .
            " - Nombre: " . $fila['nomcat'] .
            " - Estado: " . ($fila['estcat'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay categorías habilitadas";
}
echo "<hr>";

echo "<h2>Listado de Todas las Categorías</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codcat'] .
            " - Nombre: " . $fila['nomcat'] .
            " - Estado: " . ($fila['estcat'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay categorías registradas";
}
echo "<hr>";

echo "<h2>Registrar Categoría</h2>";
$nomcat = "Electrónica de Prueba";
$estcat = 1;
$resultado = $modelo->add($nomcat, $estcat);
echo $resultado ? "Categoría registrada correctamente" : "Error al registrar la categoría";
echo "<hr>";

echo "<h2>Buscar Categoría por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codcat'] . " - Nombre: " . $fila['nomcat'] .
        " - Estado: " . ($fila['estcat'] ? 'Habilitado' : 'Deshabilitado');
} else {
    echo "No existe la categoría con código $codigo";
}
echo "<hr>";

echo "<h2>Actualizar Categoría</h2>";
$codcat = 1;
$nomcat = "Electrónica Actualizada";
$estcat = 1;
$resultado = $modelo->update($codcat, $nomcat, $estcat);
echo $resultado ? "Categoría actualizada correctamente" : "Error al actualizar la categoría";
echo "<hr>";

echo "<h2>Eliminar Categoría (Deshabilitar)</h2>";
$codcat = 1;
$resultado = $modelo->delete($codcat);
echo $resultado ? "Categoría deshabilitada correctamente" : "Error al deshabilitar la categoría";
echo "<hr>";

echo "<h2>Habilitar Categoría</h2>";
$codcat = 1;
$resultado = $modelo->enable($codcat);
echo $resultado ? "Categoría habilitada correctamente" : "Error al habilitar la categoría";
echo "<hr>";

echo "<h2>Deshabilitar Categoría</h2>";
$codcat = 1;
$resultado = $modelo->disable($codcat);
echo $resultado ? "Categoría deshabilitada correctamente" : "Error al deshabilitar la categoría";
echo "<hr>";
?>