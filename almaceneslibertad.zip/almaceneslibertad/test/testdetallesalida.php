<?php
require_once '../models/DetalleSalida.php';

$modelo = new DetalleSalida();

// Listado de todos los detalles de salida
echo "<h2>Listado de Todos los Detalles de Salida</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['nrodetsal'] .
             " - N° Salida: " . $fila['nrosal'] .
             " - Producto: " . $fila['codpro'] .
             " - Cantidad: " . $fila['cansal'] .
             " - Precio: S/ " . number_format($fila['presal'], 2) . "<br>";
    }
} else {
    echo "No hay detalles de salida registrados";
}
echo "<hr>";

// Registrar una línea de detalle de salida
echo "<h2>Registrar Detalle de Salida</h2>";
$cantidad = 5;
$precio   = 30.00;
$nrosal   = 1;
$codpro   = 1;

$resultado = $modelo->add($cantidad, $precio, $nrosal, $codpro);
echo $resultado
    ? "Detalle de salida registrado correctamente"
    : "Error al registrar el detalle de salida";
echo "<hr>";

// Buscar detalles por número de salida (maestro)
echo "<h2>Buscar Detalles por N° de Salida</h2>";
$nrosal = 1;
$resultado = $modelo->findById($nrosal);
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['nrodetsal'] .
             " - Producto cód: " . $fila['codpro'] .
             " - Cantidad: " . $fila['cansal'] .
             " - Precio: S/ " . number_format($fila['presal'], 2) . "<br>";
    }
} else {
    echo "No hay detalles para el registro de salida N° $nrosal";
}
echo "<hr>";

// Actualizar una fila de detalle de salida
echo "<h2>Actualizar Detalle de Salida</h2>";
$nrodetsal = 1;
$cantidad  = 8;
$precio    = 32.50;
$nrosal    = 1;
$codpro    = 1;

$resultado = $modelo->update($nrodetsal, $cantidad, $precio, $nrosal, $codpro);
echo $resultado
    ? "Detalle de salida actualizado correctamente"
    : "Error al actualizar el detalle de salida";
echo "<hr>";

// Eliminar detalles físicamente por número de salida
echo "<h2>Eliminar Detalles de Salida (por N° Salida)</h2>";
$nrosal = 1;
$resultado = $modelo->delete($nrosal);
echo $resultado
    ? "Detalles de salida eliminados correctamente (N° salida: $nrosal)"
    : "Error al eliminar los detalles de salida";
echo "<hr>";
?>
