<?php
require_once '../models/Traslado.php';

$modelo = new Traslado();

// Listado de traslados habilitados
echo "<h2>Listado de Traslados Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codtra'] .
             " - Fecha: " . $fila['fectra'] .
             " - Origen: " . $fila['nomalmacen_origen'] .
             " - Destino: " . $fila['nomalmacen_destino'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Estado: " . ($fila['esttra'] ? 'Activo' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay traslados habilitados";
}
echo "<hr>";

// Listado de todos los traslados
echo "<h2>Listado de Todos los Traslados</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codtra'] .
             " - Fecha: " . $fila['fectra'] .
             " - Origen: " . $fila['nomalmacen_origen'] .
             " - Destino: " . $fila['nomalmacen_destino'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Estado: " . ($fila['esttra'] ? 'Activo' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay traslados registrados";
}
echo "<hr>";

// Registrar cabecera de traslado
echo "<h2>Registrar Traslado</h2>";
$fecha          = date('Y-m-d');
$almacenOrigen  = 1;
$almacenDestino = 2;
$empleado       = 1;
$estado         = 1;

$codtra = $modelo->add($fecha, $almacenOrigen, $almacenDestino, $empleado, $estado);
echo $codtra
    ? "Traslado registrado correctamente. Código asignado: $codtra"
    : "Error al registrar el traslado";
echo "<hr>";

// Buscar traslado por código
echo "<h2>Buscar Traslado por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codtra'] .
         " - Fecha: " . $fila['fectra'] .
         " - Origen: " . $fila['nomalmacen_origen'] .
         " - Destino: " . $fila['nomalmacen_destino'] .
         " - Empleado: " . $fila['nomempleado'] .
         " - Estado: " . ($fila['esttra'] ? 'Activo' : 'Anulado');
} else {
    echo "No existe el traslado con código $codigo";
}
echo "<hr>";

// Actualizar traslado
echo "<h2>Actualizar Traslado</h2>";
$codtra         = 1;
$fecha          = date('Y-m-d');
$almacenOrigen  = 1;
$almacenDestino = 2;
$empleado       = 1;
$estado         = 1;

$resultado = $modelo->update($codtra, $fecha, $almacenOrigen, $almacenDestino, $empleado, $estado);
echo $resultado
    ? "Traslado actualizado correctamente"
    : "Error al actualizar el traslado";
echo "<hr>";

// Anular traslado (eliminación lógica)
echo "<h2>Anular Traslado (Deshabilitar)</h2>";
$codtra = 1;
$resultado = $modelo->delete($codtra);
echo $resultado
    ? "Traslado anulado correctamente"
    : "Error al anular el traslado";
echo "<hr>";

// Habilitar traslado
echo "<h2>Habilitar Traslado</h2>";
$codtra = 1;
$resultado = $modelo->enable($codtra);
echo $resultado
    ? "Traslado habilitado correctamente"
    : "Error al habilitar el traslado";
echo "<hr>";

// Deshabilitar traslado
echo "<h2>Deshabilitar Traslado</h2>";
$codtra = 1;
$resultado = $modelo->disable($codtra);
echo $resultado
    ? "Traslado deshabilitado correctamente"
    : "Error al deshabilitar el traslado";
echo "<hr>";
?>
