<?php
require_once '../models/RegistroSalida.php';

$modelo = new RegistroSalida();

// Listado de salidas habilitadas
echo "<h2>Listado de Registros de Salida Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Salida: " . $fila['nrosal'] .
             " - Fecha: " . $fila['fecsal'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Almacén: " . $fila['nomalm'] .
             " - Estado: " . ($fila['estsal'] ? 'Habilitado' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay registros de salida habilitados";
}
echo "<hr>";

// Listado de todos los registros de salida
echo "<h2>Listado de Todos los Registros de Salida</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Salida: " . $fila['nrosal'] .
             " - Fecha: " . $fila['fecsal'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Almacén: " . $fila['nomalm'] .
             " - Estado: " . ($fila['estsal'] ? 'Habilitado' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay registros de salida";
}
echo "<hr>";

// Registrar cabecera de salida
echo "<h2>Registrar Registro de Salida</h2>";
$fecha    = date('Y-m-d');
$empleado = 1;
$almacen  = 1;
$estado   = 1;

$nrosal = $modelo->add($fecha, $empleado, $almacen, $estado);
echo $nrosal
    ? "Registro de salida creado correctamente. N° asignado: $nrosal"
    : "Error al registrar la salida";
echo "<hr>";

// Buscar registro de salida por número
echo "<h2>Buscar Registro de Salida por N°</h2>";
$numero = 1;
$resultado = $modelo->findById($numero);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "N° Salida: " . $fila['nrosal'] .
         " - Fecha: " . $fila['fecsal'] .
         " - Empleado: " . $fila['nomempleado'] .
         " - Almacén: " . $fila['nomalm'] .
         " - Estado: " . ($fila['estsal'] ? 'Habilitado' : 'Anulado');
} else {
    echo "No existe el registro de salida N° $numero";
}
echo "<hr>";

// Actualizar registro de salida
echo "<h2>Actualizar Registro de Salida</h2>";
$nrosal   = 1;
$fecha    = date('Y-m-d');
$empleado = 1;
$almacen  = 1;
$estado   = 1;

$resultado = $modelo->update($nrosal, $fecha, $empleado, $almacen, $estado);
echo $resultado
    ? "Registro de salida actualizado correctamente"
    : "Error al actualizar el registro de salida";
echo "<hr>";

// Anular registro de salida (eliminación lógica)
echo "<h2>Anular Registro de Salida (Deshabilitar)</h2>";
$nrosal = 1;
$resultado = $modelo->delete($nrosal);
echo $resultado
    ? "Registro de salida anulado correctamente"
    : "Error al anular el registro de salida";
echo "<hr>";

// Habilitar registro de salida
echo "<h2>Habilitar Registro de Salida</h2>";
$nrosal = 1;
$resultado = $modelo->enable($nrosal);
echo $resultado
    ? "Registro de salida habilitado correctamente"
    : "Error al habilitar el registro de salida";
echo "<hr>";

// Deshabilitar registro de salida
echo "<h2>Deshabilitar Registro de Salida</h2>";
$nrosal = 1;
$resultado = $modelo->disable($nrosal);
echo $resultado
    ? "Registro de salida deshabilitado correctamente"
    : "Error al deshabilitar el registro de salida";
echo "<hr>";
?>
