<?php
require_once '../models/Producto.php';
$modelo = new Producto();

echo "<h2>Listado de Productos Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codpro'] .
            " - Nombre: " . $fila['nompro'] .
            " - Precio: S/ " . $fila['prepro'] .
            " - Stock: " . $fila['canpro'] .
            " - Categoría: " . $fila['nomcat'] .
            " - Marca: " . $fila['nommar'] .
            " - Estado: " . ($fila['estpro'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay productos habilitados";
}
echo "<hr>";

echo "<h2>Listado de Todos los Productos</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codpro'] .
            " - Nombre: " . $fila['nompro'] .
            " - Precio: S/ " . $fila['prepro'] .
            " - Categoría: " . $fila['nomcat'] .
            " - Marca: " . $fila['nommar'] .
            " - Estado: " . ($fila['estpro'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay productos registrados";
}
echo "<hr>";

echo "<h2>Registrar Producto</h2>";
$nombre      = "Laptop Core i7 Prueba";
$descripcion = "Laptop de alto rendimiento para oficina";
$precio      = 3500.00;
$cantidad    = 10;
$estado      = 1;
$categoria   = 1; // Ajustar a codcat existente
$marca       = 1; // Ajustar a codmar existente
$resultado = $modelo->add($nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca);
echo $resultado ? "Producto registrado correctamente" : "Error al registrar el producto";
echo "<hr>";

echo "<h2>Buscar Producto por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codpro'] .
        " - Nombre: " . $fila['nompro'] .
        " - Precio: S/ " . $fila['prepro'] .
        " - Stock: " . $fila['canpro'] .
        " - Categoría: " . $fila['nomcat'] .
        " - Marca: " . $fila['nommar'];
} else {
    echo "No existe el producto con código $codigo";
}
echo "<hr>";

echo "<h2>Actualizar Producto</h2>";
$codpro      = 1;
$nombre      = "Laptop Core i7 Actualizada";
$descripcion = "Laptop de alto rendimiento - versión actualizada";
$precio      = 3800.00;
$cantidad    = 8;
$estado      = 1;
$categoria   = 1;
$marca       = 1;
$resultado = $modelo->update($codpro, $nombre, $descripcion, $precio, $cantidad, $estado, $categoria, $marca);
echo $resultado ? "Producto actualizado correctamente" : "Error al actualizar el producto";
echo "<hr>";

echo "<h2>Eliminar Producto (Deshabilitar)</h2>";
$codpro = 1;
$resultado = $modelo->delete($codpro);
echo $resultado ? "Producto deshabilitado correctamente" : "Error al deshabilitar el producto";
echo "<hr>";

echo "<h2>Habilitar Producto</h2>";
$codpro = 1;
$resultado = $modelo->enable($codpro);
echo $resultado ? "Producto habilitado correctamente" : "Error al habilitar el producto";
echo "<hr>";

echo "<h2>Deshabilitar Producto</h2>";
$codpro = 1;
$resultado = $modelo->disable($codpro);
echo $resultado ? "Producto deshabilitado correctamente" : "Error al deshabilitar el producto";
echo "<hr>";
