<?php
require_once '../models/Rol.php';
$modelo = new Rol();

echo "<h2>Listado de Roles Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codrol'] .
            " - Nombre: " . $fila['nomrol'] .
            " - Estado: " . ($fila['estrol'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay roles habilitados";
}
echo "<hr>";

echo "<h2>Listado de Todos los Roles</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codrol'] .
            " - Nombre: " . $fila['nomrol'] .
            " - Estado: " . ($fila['estrol'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay roles registrados";
}
echo "<hr>";

echo "<h2>Registrar Rol</h2>";
$nomrol = "Supervisor de Almacén";
$estrol = 1;
$resultado = $modelo->add($nomrol, $estrol);
echo $resultado ? "Rol registrado correctamente" : "Error al registrar el rol";
echo "<hr>";

echo "<h2>Buscar Rol por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codrol'] . " - Nombre: " . $fila['nomrol'] .
        " - Estado: " . ($fila['estrol'] ? 'Habilitado' : 'Deshabilitado');
} else {
    echo "No existe el rol con código $codigo";
}
echo "<hr>";

echo "<h2>Actualizar Rol</h2>";
$codrol = 1;
$nomrol = "Supervisor Actualizado";
$estrol = 1;
$resultado = $modelo->update($codrol, $nomrol, $estrol);
echo $resultado ? "Rol actualizado correctamente" : "Error al actualizar el rol";
echo "<hr>";

echo "<h2>Eliminar Rol (Deshabilitar)</h2>";
$codrol = 1;
$resultado = $modelo->delete($codrol);
echo $resultado ? "Rol deshabilitado correctamente" : "Error al deshabilitar el rol";
echo "<hr>";

echo "<h2>Habilitar Rol</h2>";
$codrol = 1;
$resultado = $modelo->enable($codrol);
echo $resultado ? "Rol habilitado correctamente" : "Error al habilitar el rol";
echo "<hr>";

echo "<h2>Deshabilitar Rol</h2>";
$codrol = 1;
$resultado = $modelo->disable($codrol);
echo $resultado ? "Rol deshabilitado correctamente" : "Error al deshabilitar el rol";
echo "<hr>";
