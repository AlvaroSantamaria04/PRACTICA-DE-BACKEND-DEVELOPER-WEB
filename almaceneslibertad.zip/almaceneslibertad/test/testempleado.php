<?php
require_once '../models/Empleado.php';

$modelo = new Empleado();

// Listado de empleados habilitados
echo "<h2>Listado de Empleados Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codemp'] .
            " - Empleado: " . $fila['apepemp'] . " " . $fila['apememp'] . ", " . $fila['nomemp'] .
            " - Doc: " . $fila['docemp'] . " (" . $fila['nomtipd'] . ")" .
            " - Dirección: " . $fila['diremp'] . " (" . $fila['nomdis'] . ")" .
            " - Celular: " . $fila['celemp'] .
            " - Correo: " . $fila['coremp'] .
            " - Sucursal: " . $fila['nomsuc'] .
            " - Rol: " . $fila['nomrol'] .
            " - Sexo: " . $fila['nomsex'] .
            " - Estado: " . ($fila['estemp'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay empleados habilitados";
}
echo "<hr>";

// Listado de todos los empleados
echo "<h2>Listado de Todos los Empleados</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codemp'] .
            " - Empleado: " . $fila['apepemp'] . " " . $fila['apememp'] . ", " . $fila['nomemp'] .
            " - Doc: " . $fila['docemp'] . " (" . $fila['nomtipd'] . ")" .
            " - Sucursal: " . $fila['nomsuc'] .
            " - Rol: " . $fila['nomrol'] .
            " - Estado: " . ($fila['estemp'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay empleados registrados";
}
echo "<hr>";

// Registrar empleado
echo "<h2>Registrar Empleado</h2>";
$nomemp    = "Juan";
$apepemp   = "Pérez";
$apememp   = "García";
$docemp    = "12345678";
$diremp    = "Av. Lima 456";
$telemp    = "0123456";
$celemp    = "987654321";
$coremp    = "juan.perez@almacenes.com";
$estemp    = 1;
$coddis    = 1;
$codrol    = 1;
$codtipd   = 1;
$codsuc    = 1;
$codsex    = 1;

$resultado = $modelo->add(
    $nomemp,
    $apepemp,
    $apememp,
    $docemp,
    $diremp,
    $telemp,
    $celemp,
    $coremp,
    $estemp,
    $coddis,
    $codrol,
    $codtipd,
    $codsuc,
    $codsex
);
echo $resultado
    ? "Empleado registrado correctamente"
    : "Error al registrar el empleado";
echo "<hr>";

// Buscar empleado por código
echo "<h2>Buscar Empleado por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codemp'] .
        " - Empleado: " . $fila['apepemp'] . " " . $fila['apememp'] . ", " . $fila['nomemp'] .
        " - Doc: " . $fila['docemp'] . " (" . $fila['nomtipd'] . ")" .
        " - Sucursal: " . $fila['nomsuc'] .
        " - Rol: " . $fila['nomrol'] .
        " - Estado: " . ($fila['estemp'] ? 'Habilitado' : 'Deshabilitado');
} else {
    echo "No existe el empleado con código $codigo";
}
echo "<hr>";

// Actualizar empleado
echo "<h2>Actualizar Empleado</h2>";
$codemp    = 1;
$nomemp    = "Juan Modificado";
$apepemp   = "Pérez";
$apememp   = "García";
$docemp    = "12345678";
$diremp    = "Av. Lima 456 - Int. 3";
$telemp    = "0123456";
$celemp    = "987654321";
$coremp    = "juan.nuevo@almacenes.com";
$estemp    = 1;
$coddis    = 1;
$codrol    = 1;
$codtipd   = 1;
$codsuc    = 1;
$codsex    = 1;

$resultado = $modelo->update(
    $codemp,
    $nomemp,
    $apepemp,
    $apememp,
    $docemp,
    $diremp,
    $telemp,
    $celemp,
    $coremp,
    $estemp,
    $coddis,
    $codrol,
    $codtipd,
    $codsuc,
    $codsex
);
echo $resultado
    ? "Empleado actualizado correctamente"
    : "Error al actualizar el empleado";
echo "<hr>";

// Eliminar empleado (deshabilitar)
echo "<h2>Eliminar Empleado (Deshabilitar)</h2>";
$codemp = 1;
$resultado = $modelo->delete($codemp);
echo $resultado
    ? "Empleado deshabilitado correctamente"
    : "Error al deshabilitar el empleado";
echo "<hr>";

// Habilitar empleado
echo "<h2>Habilitar Empleado</h2>";
$codemp = 1;
$resultado = $modelo->enable($codemp);
echo $resultado
    ? "Empleado habilitado correctamente"
    : "Error al habilitar el empleado";
echo "<hr>";

// Deshabilitar empleado
echo "<h2>Deshabilitar Empleado</h2>";
$codemp = 1;
$resultado = $modelo->disable($codemp);
echo $resultado
    ? "Empleado deshabilitado correctamente"
    : "Error al deshabilitar el empleado";
echo "<hr>";

// Login del sistema
echo "<h2>Login del Sistema</h2>";
$usuario = "juan.perez@almacenes.com";
$clave   = "987654321"; // celemp usado como clave en el modelo
$empleado = $modelo->login($usuario, $clave);
if ($empleado) {
    echo "Login exitoso - Bienvenido: " . $empleado['apepemp'] . " " . $empleado['nomemp'] .
        " | Rol: " . $empleado['nomrol'];
} else {
    echo "Usuario o clave incorrecta";
}
echo "<hr>";
?>