<?php
require_once '../models/RegistroEntrada.php';

$modelo = new RegistroEntrada();

// Listado de entradas habilitadas
echo "<h2>Listado de Registros de Entrada Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Entrada: " . $fila['nroent'] .
             " - Fecha: " . $fila['fecent'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Proveedor: " . $fila['nomprov'] .
             " - Almacén: " . $fila['nomalm'] .
             " - Estado: " . ($fila['estent'] ? 'Habilitado' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay registros de entrada habilitados";
}
echo "<hr>";

// Listado de todos los registros de entrada
echo "<h2>Listado de Todos los Registros de Entrada</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Entrada: " . $fila['nroent'] .
             " - Fecha: " . $fila['fecent'] .
             " - Empleado: " . $fila['nomempleado'] .
             " - Proveedor: " . $fila['nomprov'] .
             " - Almacén: " . $fila['nomalm'] .
             " - Estado: " . ($fila['estent'] ? 'Habilitado' : 'Anulado') . "<br>";
    }
} else {
    echo "No hay registros de entrada";
}
echo "<hr>";

// Registrar cabecera de entrada
echo "<h2>Registrar Registro de Entrada</h2>";
$fecha     = date('Y-m-d');
$empleado  = 1;
$proveedor = 1;
$almacen   = 1;
$estado    = 1;

$nroent = $modelo->add($fecha, $empleado, $proveedor, $almacen, $estado);
echo $nroent
    ? "Registro de entrada creado correctamente. N° asignado: $nroent"
    : "Error al registrar la entrada";
echo "<hr>";

// Buscar registro de entrada por número
echo "<h2>Buscar Registro de Entrada por N°</h2>";
$numero = 1;
$resultado = $modelo->findById($numero);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "N° Entrada: " . $fila['nroent'] .
         " - Fecha: " . $fila['fecent'] .
         " - Empleado: " . $fila['nomempleado'] .
         " - Proveedor: " . $fila['nomprov'] .
         " - Almacén: " . $fila['nomalm'] .
         " - Estado: " . ($fila['estent'] ? 'Habilitado' : 'Anulado');
} else {
    echo "No existe el registro de entrada N° $numero";
}
echo "<hr>";

// Actualizar registro de entrada
echo "<h2>Actualizar Registro de Entrada</h2>";
$nroent    = 1;
$fecha     = date('Y-m-d');
$empleado  = 1;
$proveedor = 1;
$almacen   = 1;
$estado    = 1;

$resultado = $modelo->update($nroent, $fecha, $empleado, $proveedor, $almacen, $estado);
echo $resultado
    ? "Registro de entrada actualizado correctamente"
    : "Error al actualizar el registro de entrada";
echo "<hr>";

// Anular registro de entrada (eliminación lógica)
echo "<h2>Anular Registro de Entrada (Deshabilitar)</h2>";
$nroent = 1;
$resultado = $modelo->delete($nroent);
echo $resultado
    ? "Registro de entrada anulado correctamente"
    : "Error al anular el registro de entrada";
echo "<hr>";

// Habilitar registro de entrada
echo "<h2>Habilitar Registro de Entrada</h2>";
$nroent = 1;
$resultado = $modelo->enable($nroent);
echo $resultado
    ? "Registro de entrada habilitado correctamente"
    : "Error al habilitar el registro de entrada";
echo "<hr>";

// Deshabilitar registro de entrada
echo "<h2>Deshabilitar Registro de Entrada</h2>";
$nroent = 1;
$resultado = $modelo->disable($nroent);
echo $resultado
    ? "Registro de entrada deshabilitado correctamente"
    : "Error al deshabilitar el registro de entrada";
echo "<hr>";
?>
