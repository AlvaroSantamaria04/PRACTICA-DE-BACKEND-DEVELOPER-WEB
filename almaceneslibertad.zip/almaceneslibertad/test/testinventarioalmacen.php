<?php
require_once '../models/InventarioAlmacen.php';
$modelo = new InventarioAlmacen();

// NOTA: InventarioAlmacen NO tiene campo estado; no se prueban habilitar/deshabilitar.
echo "<h2>Listado de Inventario</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Inv: " . $fila['codinv'] .
            " - Almacén: " . $fila['nomalm'] .
            " - Producto: " . $fila['nompro'] .
            " - Stock Actual: " . $fila['stockactual'] . "<br>";
    }
} else {
    echo "No hay registros de inventario";
}
echo "<hr>";

echo "<h2>Registrar en Inventario</h2>";
$almacen  = 1; // Ajustar a codalm existente
$producto = 1; // Ajustar a codpro existente
$stock    = 50;
$resultado = $modelo->add($almacen, $producto, $stock);
echo $resultado ? "Inventario registrado correctamente" : "Error al registrar en inventario";
echo "<hr>";

echo "<h2>Buscar Inventario por ID</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Inv: " . $fila['codinv'] .
        " - Almacén: " . $fila['nomalm'] .
        " - Producto: " . $fila['nompro'] .
        " - Stock: " . $fila['stockactual'];
} else {
    echo "No existe el registro con código $codigo";
}
echo "<hr>";

echo "<h2>Buscar por Almacén y Producto</h2>";
$almacen  = 1;
$producto = 1;
$resultado = $modelo->findByAlmacenProducto($almacen, $producto);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Stock en " . $fila['nomalm'] . " del producto " . $fila['nompro'] . ": " . $fila['stockactual'];
} else {
    echo "No hay stock registrado para ese almacén/producto";
}
echo "<hr>";

echo "<h2>Actualizar Stock</h2>";
$codinv = 1;
$stock  = 75;
$resultado = $modelo->update($codinv, $stock);
echo $resultado ? "Stock actualizado correctamente" : "Error al actualizar el stock";
echo "<hr>";

echo "<h2>Actualizar Stock por Almacén y Producto</h2>";
$almacen  = 1;
$producto = 1;
$stock    = 80;
$resultado = $modelo->updateStockByAlmacenProducto($almacen, $producto, $stock);
echo $resultado ? "Stock actualizado por almacén/producto correctamente" : "Error al actualizar";
echo "<hr>";

echo "<h2>Eliminar Registro de Inventario (físico)</h2>";
// Usar un codinv de prueba; no eliminar registros reales en producción
$codinv = 99;
$resultado = $modelo->delete($codinv);
echo $resultado ? "Registro eliminado correctamente" : "No existe o error al eliminar";
echo "<hr>";
