<?php
require_once '../models/DetalleEntrada.php';

$modelo = new DetalleEntrada();

// Listado de todos los detalles de entrada
echo "<h2>Listado de Todos los Detalles de Entrada</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['nrodetent'] .
             " - N° Entrada: " . $fila['nroent'] .
             " - Producto: " . $fila['codpro'] .
             " - Cantidad: " . $fila['canent'] .
             " - Precio: S/ " . number_format($fila['preent'], 2) . "<br>";
    }
} else {
    echo "No hay detalles de entrada registrados";
}
echo "<hr>";

// Registrar una línea de detalle de entrada
echo "<h2>Registrar Detalle de Entrada</h2>";
$cantidad = 10;
$precio   = 25.50;
$nroent   = 1;
$codpro   = 1;

$resultado = $modelo->add($cantidad, $precio, $nroent, $codpro);
echo $resultado
    ? "Detalle de entrada registrado correctamente"
    : "Error al registrar el detalle de entrada";
echo "<hr>";

// Buscar detalles por número de entrada (maestro)
echo "<h2>Buscar Detalles por N° de Entrada</h2>";
$nroent = 1;
$resultado = $modelo->findById($nroent);
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['nrodetent'] .
             " - Producto cód: " . $fila['codpro'] .
             " - Cantidad: " . $fila['canent'] .
             " - Precio: S/ " . number_format($fila['preent'], 2) . "<br>";
    }
} else {
    echo "No hay detalles para el registro de entrada N° $nroent";
}
echo "<hr>";

// Actualizar una fila de detalle de entrada
echo "<h2>Actualizar Detalle de Entrada</h2>";
$nrodetent = 1;
$cantidad  = 15;
$precio    = 27.00;
$nroent    = 1;
$codpro    = 1;

$resultado = $modelo->update($nrodetent, $cantidad, $precio, $nroent, $codpro);
echo $resultado
    ? "Detalle de entrada actualizado correctamente"
    : "Error al actualizar el detalle de entrada";
echo "<hr>";

// Eliminar detalles físicamente por número de entrada
echo "<h2>Eliminar Detalles de Entrada (por N° Entrada)</h2>";
$nroent = 1;
$resultado = $modelo->delete($nroent);
echo $resultado
    ? "Detalles de entrada eliminados correctamente (N° entrada: $nroent)"
    : "Error al eliminar los detalles de entrada";
echo "<hr>";
?>
