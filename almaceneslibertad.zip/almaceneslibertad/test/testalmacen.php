<?php
require_once '../models/Almacen.php';
$modelo = new Almacen();

echo "<h2>Listado de Almacenes Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codalm'] .
             " - Nombre: " . $fila['nomalm'] .
             " - Tipo: " . $fila['tipoalm'] .
             " - Dirección: " . $fila['diralm'] .
             " - Sucursal: " . ($fila['nomsuc'] ?? 'Central') .
             " - Estado: " . ($fila['estalm'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else { echo "No hay almacenes habilitados"; }
echo "<hr>";

echo "<h2>Listado de Todos los Almacenes</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codalm'] .
             " - Nombre: " . $fila['nomalm'] .
             " - Tipo: " . $fila['tipoalm'] .
             " - Sucursal: " . ($fila['nomsuc'] ?? 'Central') .
             " - Estado: " . ($fila['estalm'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else { echo "No hay almacenes registrados"; }
echo "<hr>";

echo "<h2>Registrar Almacén</h2>";
$nombre    = "Almacén Prueba Norte";
$tipo      = "Sucursal";
$direccion = "Av. Industrial 456";
$estado    = 1;
$codsuc    = 1; // Ajustar a un codsuc existente
$resultado = $modelo->add($nombre, $tipo, $direccion, $estado, $codsuc);
echo $resultado ? "Almacén registrado correctamente" : "Error al registrar el almacén";
echo "<hr>";

echo "<h2>Buscar Almacén por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codalm'] .
         " - Nombre: " . $fila['nomalm'] .
         " - Tipo: " . $fila['tipoalm'] .
         " - Sucursal: " . ($fila['nomsuc'] ?? 'Central');
} else { echo "No existe el almacén con código $codigo"; }
echo "<hr>";

echo "<h2>Actualizar Almacén</h2>";
$codalm    = 1;
$nombre    = "Almacén Principal Modificado";
$tipo      = "Central";
$direccion = "Jr. Principal 789";
$estado    = 1;
$codsuc    = null;
$resultado = $modelo->update($codalm, $nombre, $tipo, $direccion, $estado, $codsuc);
echo $resultado ? "Almacén actualizado correctamente" : "Error al actualizar el almacén";
echo "<hr>";

echo "<h2>Eliminar Almacén (Deshabilitar)</h2>";
$codalm = 1;
$resultado = $modelo->delete($codalm);
echo $resultado ? "Almacén deshabilitado correctamente" : "Error al deshabilitar el almacén";
echo "<hr>";

echo "<h2>Habilitar Almacén</h2>";
$codalm = 1;
$resultado = $modelo->enable($codalm);
echo $resultado ? "Almacén habilitado correctamente" : "Error al habilitar el almacén";
echo "<hr>";

echo "<h2>Deshabilitar Almacén</h2>";
$codalm = 1;
$resultado = $modelo->disable($codalm);
echo $resultado ? "Almacén deshabilitado correctamente" : "Error al deshabilitar el almacén";
echo "<hr>";
?>