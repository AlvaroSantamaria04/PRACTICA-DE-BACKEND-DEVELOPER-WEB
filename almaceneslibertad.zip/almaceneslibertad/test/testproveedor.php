<?php
require_once '../models/Proveedor.php';
$modelo = new Proveedor();

echo "<h2>Listado de Proveedores Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codprov'] .
             " - Empresa: " . $fila['nomprov'] .
             " - Representante: " . $fila['repprov'] .
             " - Distrito: " . $fila['nomdis'] .
             " - Celular: " . $fila['celprov'] .
             " - Correo: " . $fila['corprov'] .
             " - Estado: " . ($fila['estprov'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else { echo "No hay proveedores habilitados"; }
echo "<hr>";

echo "<h2>Listado de Todos los Proveedores</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codprov'] .
             " - Empresa: " . $fila['nomprov'] .
             " - Representante: " . $fila['repprov'] .
             " - Distrito: " . $fila['nomdis'] .
             " - Estado: " . ($fila['estprov'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else { echo "No hay proveedores registrados"; }
echo "<hr>";

echo "<h2>Registrar Proveedor</h2>";
$nombre        = "Distribuidora Libertad S.A.C.";
$representante = "Carlos López";
$direccion     = "Av. Industrial 123, Lima";
$telefono      = "2345678";
$celular       = "987654321";
$correo        = "distribuidora@libertad.com";
$estado        = 1;
$distrito      = 1;
$resultado = $modelo->add($nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito);
echo $resultado ? "Proveedor registrado correctamente" : "Error al registrar el proveedor";
echo "<hr>";

echo "<h2>Buscar Proveedor por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codprov'] .
         " - Empresa: " . $fila['nomprov'] .
         " - Representante: " . $fila['repprov'] .
         " - Distrito: " . $fila['nomdis'];
} else { echo "No existe el proveedor con código $codigo"; }
echo "<hr>";

echo "<h2>Actualizar Proveedor</h2>";
$codprov       = 1;
$nombre        = "Distribuidora Libertad Modificada";
$representante = "Carlos López García";
$direccion     = "Av. Industrial 123, Lima - Of. 2";
$telefono      = "2345679";
$celular       = "987654322";
$correo        = "dist.libertad@correo.com";
$estado        = 1;
$distrito      = 1;
$resultado = $modelo->update($codprov, $nombre, $representante, $direccion, $telefono, $celular, $correo, $estado, $distrito);
echo $resultado ? "Proveedor actualizado correctamente" : "Error al actualizar el proveedor";
echo "<hr>";

echo "<h2>Eliminar Proveedor (Deshabilitar)</h2>";
$codprov = 1;
$resultado = $modelo->delete($codprov);
echo $resultado ? "Proveedor deshabilitado correctamente" : "Error al deshabilitar el proveedor";
echo "<hr>";

echo "<h2>Habilitar Proveedor</h2>";
$codprov = 1;
$resultado = $modelo->enable($codprov);
echo $resultado ? "Proveedor habilitado correctamente" : "Error al habilitar el proveedor";
echo "<hr>";

echo "<h2>Deshabilitar Proveedor</h2>";
$codprov = 1;
$resultado = $modelo->disable($codprov);
echo $resultado ? "Proveedor deshabilitado correctamente" : "Error al deshabilitar el proveedor";
echo "<hr>";
?>