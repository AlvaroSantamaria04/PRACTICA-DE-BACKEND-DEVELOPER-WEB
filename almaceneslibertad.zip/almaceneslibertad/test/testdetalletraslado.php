<?php
require_once '../models/DetalleTraslado.php';

$modelo = new DetalleTraslado();

// Listado de todos los detalles de traslado
echo "<h2>Listado de Todos los Detalles de Traslado</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['coddettra'] .
             " - Traslado: " . $fila['codtra'] .
             " - Producto: " . $fila['codpro'] .
             " - Cantidad: " . $fila['cantra'] . "<br>";
    }
} else {
    echo "No hay detalles de traslado registrados";
}
echo "<hr>";

// Registrar una línea de detalle de traslado
echo "<h2>Registrar Detalle de Traslado</h2>";
$codtra   = 1;
$codpro   = 1;
$cantidad = 20;

$resultado = $modelo->add($codtra, $codpro, $cantidad);
echo $resultado
    ? "Detalle de traslado registrado correctamente"
    : "Error al registrar el detalle de traslado";
echo "<hr>";

// Buscar detalles por código de traslado (maestro)
echo "<h2>Buscar Detalles por Código de Traslado</h2>";
$codtra = 1;
$resultado = $modelo->findById($codtra);
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "N° Detalle: " . $fila['coddettra'] .
             " - Producto cód: " . $fila['codpro'] .
             " - Cantidad: " . $fila['cantra'] . "<br>";
    }
} else {
    echo "No hay detalles para el traslado código $codtra";
}
echo "<hr>";

// Actualizar una fila de detalle de traslado
echo "<h2>Actualizar Detalle de Traslado</h2>";
$coddettra = 1;
$codtra    = 1;
$codpro    = 1;
$cantidad  = 25;

$resultado = $modelo->update($coddettra, $codtra, $codpro, $cantidad);
echo $resultado
    ? "Detalle de traslado actualizado correctamente"
    : "Error al actualizar el detalle de traslado";
echo "<hr>";

// Eliminar detalles físicamente por código de traslado
echo "<h2>Eliminar Detalles de Traslado (por Código Traslado)</h2>";
$codtra = 1;
$resultado = $modelo->delete($codtra);
echo $resultado
    ? "Detalles de traslado eliminados correctamente (Traslado código: $codtra)"
    : "Error al eliminar los detalles de traslado";
echo "<hr>";
?>
