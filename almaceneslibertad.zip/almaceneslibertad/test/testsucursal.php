<?php
require_once '../models/Sucursal.php';
$modelo = new Sucursal();

echo "<h2>Listado de Sucursales Habilitadas</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codsuc'] .
            " - Nombre: " . $fila['nomsuc'] .
            " - Dirección: " . $fila['dirsuc'] .
            " - Celular: " . $fila['celsuc'] .
            " - Correo: " . $fila['corsuc'] .
            " - Estado: " . ($fila['estsuc'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay sucursales habilitadas";
}
echo "<hr>";

echo "<h2>Listado de Todas las Sucursales</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codsuc'] .
            " - Nombre: " . $fila['nomsuc'] .
            " - Celular: " . $fila['celsuc'] .
            " - Estado: " . ($fila['estsuc'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay sucursales registradas";
}
echo "<hr>";

echo "<h2>Registrar Sucursal</h2>";
$nombre    = "Sucursal Norte Prueba";
$direccion = "Av. Universitaria 789, Comas";
$telefono  = "5551234";
$celular   = "912345678";
$correo    = "sucursal.norte@libertad.com";
$estado    = 1;
$distrito  = 1;
$resultado = $modelo->add($nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito);
echo $resultado ? "Sucursal registrada correctamente" : "Error al registrar la sucursal";
echo "<hr>";

echo "<h2>Buscar Sucursal por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codsuc'] .
        " - Nombre: " . $fila['nomsuc'] .
        " - Dirección: " . $fila['dirsuc'] .
        " - Correo: " . $fila['corsuc'];
} else {
    echo "No existe la sucursal con código $codigo";
}
echo "<hr>";

echo "<h2>Actualizar Sucursal</h2>";
$codsuc    = 1;
$nombre    = "Sucursal Norte Modificada";
$direccion = "Av. Universitaria 789 - Piso 2, Comas";
$telefono  = "5551235";
$celular   = "912345679";
$correo    = "sucursal.norte2@libertad.com";
$estado    = 1;
$distrito  = 1;
$resultado = $modelo->update($codsuc, $nombre, $direccion, $telefono, $celular, $correo, $estado, $distrito);
echo $resultado ? "Sucursal actualizada correctamente" : "Error al actualizar la sucursal";
echo "<hr>";

echo "<h2>Eliminar Sucursal (Deshabilitar)</h2>";
$codsuc = 1;
$resultado = $modelo->delete($codsuc);
echo $resultado ? "Sucursal deshabilitada correctamente" : "Error al deshabilitar la sucursal";
echo "<hr>";

echo "<h2>Habilitar Sucursal</h2>";
$codsuc = 1;
$resultado = $modelo->enable($codsuc);
echo $resultado ? "Sucursal habilitada correctamente" : "Error al habilitar la sucursal";
echo "<hr>";

echo "<h2>Deshabilitar Sucursal</h2>";
$codsuc = 1;
$resultado = $modelo->disable($codsuc);
echo $resultado ? "Sucursal deshabilitada correctamente" : "Error al deshabilitar la sucursal";
echo "<hr>";
