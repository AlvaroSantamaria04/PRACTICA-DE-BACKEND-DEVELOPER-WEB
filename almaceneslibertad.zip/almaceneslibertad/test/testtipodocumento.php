<?php
require_once '../models/TipoDocumento.php';
$modelo = new TipoDocumento();

echo "<h2>Listado de Tipos de Documento Habilitados</h2>";
$resultado = $modelo->findAllCustom();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codtipd'] .
            " - Nombre: " . $fila['nomtipd'] .
            " - Estado: " . ($fila['esttipd'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay tipos de documento habilitados";
}
echo "<hr>";

echo "<h2>Listado de Todos los Tipos de Documento</h2>";
$resultado = $modelo->findAll();
if ($resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        echo "Código: " . $fila['codtipd'] .
            " - Nombre: " . $fila['nomtipd'] .
            " - Estado: " . ($fila['esttipd'] ? 'Habilitado' : 'Deshabilitado') . "<br>";
    }
} else {
    echo "No hay tipos de documento registrados";
}
echo "<hr>";

echo "<h2>Registrar Tipo de Documento</h2>";
$nomtipd = "Carné de Extranjería";
$esttipd = 1;
$resultado = $modelo->add($nomtipd, $esttipd);
echo $resultado ? "Tipo de documento registrado correctamente" : "Error al registrar el tipo de documento";
echo "<hr>";

echo "<h2>Buscar Tipo de Documento por Código</h2>";
$codigo = 1;
$resultado = $modelo->findById($codigo);
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    echo "Código: " . $fila['codtipd'] . " - Nombre: " . $fila['nomtipd'] .
        " - Estado: " . ($fila['esttipd'] ? 'Habilitado' : 'Deshabilitado');
} else {
    echo "No existe el tipo de documento con código $codigo";
}
echo "<hr>";

echo "<h2>Actualizar Tipo de Documento</h2>";
$codtipd = 1;
$nomtipd = "DNI Actualizado";
$esttipd = 1;
$resultado = $modelo->update($codtipd, $nomtipd, $esttipd);
echo $resultado ? "Tipo de documento actualizado correctamente" : "Error al actualizar el tipo de documento";
echo "<hr>";

echo "<h2>Eliminar Tipo de Documento (Deshabilitar)</h2>";
$codtipd = 1;
$resultado = $modelo->delete($codtipd);
echo $resultado ? "Tipo de documento deshabilitado correctamente" : "Error al deshabilitar el tipo de documento";
echo "<hr>";

echo "<h2>Habilitar Tipo de Documento</h2>";
$codtipd = 1;
$resultado = $modelo->enable($codtipd);
echo $resultado ? "Tipo de documento habilitado correctamente" : "Error al habilitar el tipo de documento";
echo "<hr>";

echo "<h2>Deshabilitar Tipo de Documento</h2>";
$codtipd = 1;
$resultado = $modelo->disable($codtipd);
echo $resultado ? "Tipo de documento deshabilitado correctamente" : "Error al deshabilitar el tipo de documento";
echo "<hr>";
